# PROJECT_INPUT@2 field guide

`PROJECT_INPUT.yaml` may use JSON syntax; JSON is valid YAML 1.2 and keeps the Project Harness runtime dependency-free.

The canonical contract is `SCHEMA-PROJECT-PREPARATION-INPUT@2` in `schemas/project_input.schema.json` (JSON Schema Draft 2020-12). All normative objects are closed with `additionalProperties: false`; the only open extension point is `skills.resolutions[].configuration`. Unknown fields are errors and are never discarded silently.

The input is semantic, not merely a form. Browser GPT must ground it in user answers, supplied documentation, and repository evidence. The deterministic engine validates the same required/allowed keys, types, enums, IDs, profiles, capabilities, task scopes, dependency DAG, and approvals without requiring the optional `jsonschema` package.

## Data sensitivity

The six accepted classifications are:

- `PUBLIC`
- `INTERNAL`
- `CONFIDENTIAL`
- `RESTRICTED`
- `SECRET`
- `REGULATED`

`UNKNOWN` is only a temporary intake answer. It keeps readiness at `WAITING_INPUT` and cannot pass the handoff gate.

## Approval gates

A `GREENFIELD` input requires four explicit approvals:

1. `project_definition`
2. `architecture_baseline`
3. `technology_baseline`
4. `codex_handoff`

A `BROWNFIELD` or `HYBRID` input requires a fifth, separate gate between Project Definition and Architecture:

1. `project_definition`
2. `brownfield_baseline`
3. `architecture_baseline`
4. `technology_baseline`
5. `codex_handoff`

Every approved record requires its own `actor` and `approved_at`. The Project Definition actor is not reused implicitly for the Brownfield Baseline. During compilation the Brownfield approval becomes an immutable `DEC-<PROJECT>-BROWNFIELD-001@1` record, and the accepted baseline references it through `accepted_by` and `accepted_at`.

## Planning and skills

For task dependencies, use a unique task `key`, `id`, or title. The compiler resolves aliases to canonical `TSK-*` IDs. Every non-`VERIFY` task needs a non-empty write scope. Every task needs commands, expected paths, or explicitly allowed manual checks.

`CREATE` and `EXTEND` skill actions are intentionally rejected by the Core preparation route. A new skill needs evaluation and activation and belongs to the later governed skill-authoring lifecycle. v0.4.1 accepts only `REUSE`, `CONFIGURE`, or `TASK_ONLY`.

## Migration from PROJECT_INPUT@1

The deterministic migration `MIG-ENGINE-0.4.0-TO-0.4.1` changes `schema_version` from `1` to `2`. For Brownfield/Hybrid it adds an unapproved `brownfield_baseline` gate when missing. It preserves unknown properties and reports their exact paths for manual correction. Reapplying the migration is idempotent and returns `NO_ACTION` once the input is already compliant.
