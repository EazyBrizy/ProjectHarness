# Codex Start

This archive is a validated Project Harness handoff. Open this directory as the repository root.

## Mandatory sequence

1. Validate the handoff:

```bash
python .harness/engine/project-harness.py validate-handoff --project .
```

2. Inspect current state:

```bash
python .harness/engine/project-harness.py status --project .
python .harness/engine/project-harness.py next --project .
```

3. Read only the current compiled prompt:

`.harness/prompts/BUNDLES_BY_RUN/CPB-HARNESS-DEMO-TASK-CLI-001-A1.md`

4. Implement only `TSK-HARNESS-DEMO-TASK-CLI-001@1`. Do not select another task, edit accepted baselines, or write outside declared scope.

5. Run Harness verification and write the Agent Task Result to `.harness/runtime/AGENT_RESULTS/RUN-HARNESS-DEMO-TASK-CLI-001-A1.json`.

6. Complete the transition. Harness will then compile the next READY task JIT.

## Non-negotiable rules

- `.harness/` is machine-owned, except the exact Agent Task Result path.
- A completed task requires an independent verification report with status PASS.
- Material ambiguity becomes a Blocker; it is not resolved by silent redesign.
- Git push, deploy and publication are not granted by this handoff.
- Future prompts are not precompiled. Run `next` after every accepted result.
