# Harness Demo Task CLI

The user can add, list and complete tasks stored in a local JSON file.

Implementation is governed by `CODEX_START.md`.
