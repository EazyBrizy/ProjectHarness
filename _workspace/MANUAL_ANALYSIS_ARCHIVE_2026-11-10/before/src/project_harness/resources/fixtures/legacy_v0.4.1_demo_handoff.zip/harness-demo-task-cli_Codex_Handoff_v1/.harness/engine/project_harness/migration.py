from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import re
import shutil
from typing import Any

from .compiler import _copy_runtime
from .errors import ValidationFailure, WaitingDecision, WaitingInput
from .hashing import sha256_file
from .project_input import (
    PROJECT_INPUT_MIGRATION_ID,
    migrate_project_input,
    validate_project_input,
)
from .registry import REGISTRY_NAMES, registry_lock
from .render import render_roadmap, render_status
from .resources import distribution_root
from .serialization import append_jsonl, load_data, write_data, atomic_write_text
from .util import ENGINE_VERSION, SCHEMA_VERSION, utc_now
from .validation import LEGACY_ENGINE_VERSION, LEGACY_SCHEMA_VERSION, validate_handoff_directory

MIGRATION_REPORT_PATH = f".harness/reports/{PROJECT_INPUT_MIGRATION_ID}.yaml"


def _approval_template() -> dict[str, Any]:
    return {"approved": False, "actor": None, "approved_at": None, "notes": None}


def _without_brownfield_approval(value: dict[str, Any]) -> dict[str, Any]:
    normalized = deepcopy(value)
    approvals = normalized.setdefault("approvals", {})
    if isinstance(approvals, dict):
        approvals["brownfield_baseline"] = _approval_template()
    return normalized


def _load_migration_input(root: Path, supplied_input: Path | None) -> tuple[dict[str, Any], dict[str, Any], str]:
    accepted_path = root / ".harness/state/PROJECT_INPUT_ACCEPTED.yaml"
    if not accepted_path.exists():
        raise ValidationFailure("Accepted PROJECT_INPUT is missing", str(accepted_path))

    stored_raw = load_data(accepted_path)
    stored, stored_report = migrate_project_input(stored_raw)
    candidate = stored
    source = accepted_path.relative_to(root).as_posix()

    if supplied_input is not None:
        supplied_path = supplied_input.expanduser().resolve()
        supplied_raw = load_data(supplied_path)
        supplied, supplied_report = migrate_project_input(supplied_raw)
        if _without_brownfield_approval(supplied) != _without_brownfield_approval(stored):
            raise ValidationFailure(
                "Migration input may only add or formalize approvals.brownfield_baseline",
                {
                    "accepted_input": str(accepted_path),
                    "supplied_input": str(supplied_path),
                    "stored_migration": stored_report,
                    "supplied_migration": supplied_report,
                },
            )
        candidate = supplied
        source = str(supplied_path)

    return candidate, stored_report, source


def _assert_project_identity(root: Path, candidate: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    project_path = root / ".harness/config/PROJECT.yaml"
    lock_path = root / ".harness/config/PROJECT_LOCK.yaml"
    try:
        project_doc = load_data(project_path)
        lock_doc = load_data(lock_path)
        project = project_doc["project"]
        lock = lock_doc["project_lock"]
    except Exception as exc:
        raise ValidationFailure("Project configuration or lock is invalid", str(exc)) from exc

    candidate_project = candidate.get("project") if isinstance(candidate, dict) else None
    if not isinstance(candidate_project, dict):
        raise ValidationFailure("PROJECT_INPUT.project is invalid")
    expected = {
        "slug": project.get("id"),
        "mode": project.get("lifecycle_mode"),
    }
    actual = {
        "slug": candidate_project.get("slug"),
        "mode": candidate_project.get("mode"),
    }
    if actual != expected:
        raise ValidationFailure(
            "Migration input does not identify the existing project",
            {"expected": expected, "actual": actual},
        )
    return project_doc, lock_doc


def _migrate_current_task_revisions(root: Path, migrated_at: str) -> list[dict[str, Any]]:
    index_path = root / ".harness/tasks/INDEX.yaml"
    index_doc = load_data(index_path)
    index = index_doc.get("task_index") if isinstance(index_doc, dict) else None
    if not isinstance(index, dict) or not isinstance(index.get("current"), dict):
        raise ValidationFailure("Task index is invalid", str(index_path))

    mappings: list[dict[str, Any]] = []
    ref_map: dict[str, str] = {}
    for task_id, rel in list(index["current"].items()):
        path = root / str(rel)
        task_doc = load_data(path)
        task = task_doc.get("task") if isinstance(task_doc, dict) else None
        if not isinstance(task, dict):
            raise ValidationFailure("Current Task envelope is invalid", str(rel))
        if task.get("status") != "COMPLETED":
            continue
        old_ref = f"{task.get('id')}@{task.get('revision')}"
        new_task = deepcopy(task)
        new_task["revision"] = int(task["revision"]) + 1
        new_task["previous_revision_ref"] = old_ref
        new_task["status"] = "DONE"
        new_task["updated_at"] = migrated_at
        new_ref = f"{new_task['id']}@{new_task['revision']}"
        new_rel = f".harness/tasks/{new_ref}.yaml"
        if (root / new_rel).exists():
            raise ValidationFailure("Canonical migration Task revision already exists unexpectedly", new_rel)
        write_data(root / new_rel, {"task": new_task})
        index["current"][task_id] = new_rel
        ref_map[old_ref] = new_ref
        mappings.append(
            {
                "entity": "task",
                "legacy_ref": old_ref,
                "canonical_ref": new_ref,
                "legacy_status": "COMPLETED",
                "canonical_status": "DONE",
                "legacy_file_rewritten": False,
            }
        )
    if mappings:
        write_data(index_path, index_doc)
        state_path = root / ".harness/state/CURRENT_STATE.yaml"
        state_doc = load_data(state_path)
        state = state_doc.get("state") if isinstance(state_doc, dict) else None
        if not isinstance(state, dict):
            raise ValidationFailure("Current state envelope is invalid", str(state_path))
        state["completed_task_refs"] = [ref_map.get(str(ref), str(ref)) for ref in state.get("completed_task_refs") or []]
        state["updated_at"] = migrated_at
        write_data(state_path, state_doc)
    return mappings


def _migrate_brownfield_baseline(
    root: Path,
    project: dict[str, Any],
    candidate: dict[str, Any],
    migrated_at: str,
) -> dict[str, Any] | None:
    mode = str(project.get("lifecycle_mode") or "").upper()
    if mode not in {"BROWNFIELD", "HYBRID"}:
        return None

    approval = ((candidate.get("approvals") or {}).get("brownfield_baseline"))
    if not isinstance(approval, dict) or approval.get("approved") is not True:
        raise WaitingDecision(
            "Explicit Brownfield Baseline approval is required before project migration",
            {"missing_approval": "brownfield_baseline", "migration_id": PROJECT_INPUT_MIGRATION_ID},
        )
    actor = approval.get("actor")
    approved_at = approval.get("approved_at")
    if not actor or not approved_at:
        raise ValidationFailure("Approved Brownfield Baseline requires actor and approved_at")

    baseline_dir = root / ".harness/canonical/DEFINITION/BROWNFIELD"
    baselines: list[tuple[Path, dict[str, Any]]] = []
    for path in sorted(baseline_dir.glob("BFB-*@*.yaml")):
        value = load_data(path)
        bfb = value.get("brownfield_baseline") if isinstance(value, dict) else None
        if isinstance(bfb, dict):
            baselines.append((path, bfb))
    if not baselines:
        raise ValidationFailure("Brownfield/Hybrid project has no Brownfield Baseline")

    ids = {str(item[1].get("id")) for item in baselines}
    if len(ids) != 1:
        raise ValidationFailure("Brownfield migration requires exactly one logical baseline", sorted(ids))
    baseline_id = next(iter(ids))
    latest_path, latest = max(baselines, key=lambda item: int(item[1].get("revision", 0)))
    project_token = project.get("id_token")
    if not project_token:
        raise ValidationFailure("project.id_token is required for migration")
    decision_id = f"DEC-{project_token}-BROWNFIELD-001"
    decision_path = root / f".harness/canonical/DECISIONS/{decision_id}@1.yaml"

    if latest.get("accepted_by") and latest.get("accepted_at"):
        if latest.get("accepted_by") != decision_id or latest.get("accepted_at") != approved_at:
            raise ValidationFailure("Existing Brownfield approval does not match the supplied explicit approval")
        if not decision_path.exists():
            raise ValidationFailure("Accepted Brownfield Baseline references a missing immutable Decision", decision_id)
        return {
            "status": "NO_ACTION",
            "baseline_ref": f"{baseline_id}@{latest['revision']}",
            "decision_ref": f"{decision_id}@1",
        }

    new_bfb = deepcopy(latest)
    old_ref = f"{baseline_id}@{latest['revision']}"
    new_bfb["revision"] = int(latest["revision"]) + 1
    new_bfb["previous_revision_ref"] = old_ref
    new_bfb["status"] = "ACCEPTED"
    new_bfb["accepted_by"] = decision_id
    new_bfb["accepted_at"] = approved_at
    new_ref = f"{baseline_id}@{new_bfb['revision']}"
    new_path = baseline_dir / f"{new_ref}.yaml"
    if new_path.exists() or decision_path.exists():
        raise ValidationFailure(
            "Brownfield migration target record already exists unexpectedly",
            {"baseline": str(new_path), "decision": str(decision_path)},
        )

    decision = {
        "id": decision_id,
        "revision": 1,
        "kind": "BROWNFIELD_BASELINE_APPROVAL",
        "actor": actor,
        "approved_at": approved_at,
        "subject_ref": new_ref,
        "status": "ACCEPTED",
    }
    write_data(decision_path, {"decision": decision})
    write_data(new_path, {"brownfield_baseline": new_bfb})
    return {
        "status": "MIGRATED",
        "legacy_baseline_ref": old_ref,
        "baseline_ref": new_ref,
        "decision_ref": f"{decision_id}@1",
        "approved_at": approved_at,
        "actor": actor,
        "legacy_file_rewritten": False,
        "migration_recorded_at": migrated_at,
    }


def _copy_current_registries(root: Path) -> tuple[dict[str, int], dict[str, str]]:
    distribution = distribution_root()
    target = root / ".harness/registries"
    target.mkdir(parents=True, exist_ok=True)
    for name in REGISTRY_NAMES:
        shutil.copy2(distribution / "registries" / f"{name}.yaml", target / f"{name}.yaml")
    return registry_lock(distribution)


def _update_human_views(root: Path, migrated_at: str) -> list[str]:
    changed: list[str] = []
    summary_path = root / "HANDOFF_SUMMARY.md"
    if summary_path.exists():
        text = summary_path.read_text(encoding="utf-8")
        updated = re.sub(r"(?m)^- Engine: `[^`]+`$", f"- Engine: `{ENGINE_VERSION}`", text)
        marker = f"- Contract migration: `{PROJECT_INPUT_MIGRATION_ID}` at `{migrated_at}`"
        if marker not in updated:
            updated = updated.rstrip() + "\n" + marker + "\n"
        if updated != text:
            atomic_write_text(summary_path, updated)
            changed.append("HANDOFF_SUMMARY.md")

    code_start = root / "CODEX_START.md"
    if code_start.exists():
        text = code_start.read_text(encoding="utf-8")
        note = (
            "\n## v0.4.1 migration note\n\n"
            "This mutable project was migrated from v0.4.0. Use `validate-project` for current state; "
            "the original `MANIFEST.sha256` remains the immutable initial-handoff baseline.\n"
        )
        if "## v0.4.1 migration note" not in text:
            atomic_write_text(code_start, text.rstrip() + note)
            changed.append("CODEX_START.md")
    return changed


def migrate_project(root: Path, *, input_path: Path | None = None) -> dict[str, Any]:
    """Migrate an extracted v0.4.0 project without rewriting immutable history."""
    root = root.expanduser().resolve()
    lock_path = root / ".harness/config/PROJECT_LOCK.yaml"
    state_path = root / ".harness/state/CURRENT_STATE.yaml"
    if not lock_path.exists() or not state_path.exists():
        raise ValidationFailure("Project Harness project files are missing", str(root))

    lock_doc = load_data(lock_path)
    lock = lock_doc.get("project_lock") if isinstance(lock_doc, dict) else None
    state_doc = load_data(state_path)
    state = state_doc.get("state") if isinstance(state_doc, dict) else None
    if not isinstance(lock, dict) or not isinstance(state, dict):
        raise ValidationFailure("Project lock or state envelope is invalid")

    current = lock.get("harness_distribution") == ENGINE_VERSION and lock.get("schema_version") == SCHEMA_VERSION
    already_applied = PROJECT_INPUT_MIGRATION_ID in set(lock.get("migrations_applied") or [])
    if current and already_applied:
        validation = validate_handoff_directory(
            root,
            check_manifest=False,
            check_control_plane_state=True,
        )
        if validation["status"] != "PASS":
            raise ValidationFailure(
                "Project records the v0.4.1 migration but does not conform to the current contract",
                validation["errors"],
            )
        return {
            "status": "NO_ACTION",
            "migration_id": PROJECT_INPUT_MIGRATION_ID,
            "project": str(root),
            "engine_version": ENGINE_VERSION,
            "schema_version": SCHEMA_VERSION,
            "validation_status": validation["status"],
        }
    if lock.get("harness_distribution") != LEGACY_ENGINE_VERSION or lock.get("schema_version") != LEGACY_SCHEMA_VERSION:
        raise ValidationFailure(
            "Unsupported project migration source",
            {
                "actual": {
                    "engine": lock.get("harness_distribution"),
                    "schema": lock.get("schema_version"),
                },
                "supported": {"engine": LEGACY_ENGINE_VERSION, "schema": LEGACY_SCHEMA_VERSION},
            },
        )
    if isinstance(state.get("active_run"), dict):
        raise ValidationFailure(
            "Project migration is prohibited while a Run is active",
            {
                "active_run": state["active_run"].get("run_ref"),
                "required_route": "COMPLETE_BLOCK_OR_CANCEL_ACTIVE_RUN_BEFORE_MIGRATION",
            },
        )

    preflight = validate_handoff_directory(root, check_manifest=False, check_control_plane_state=False)
    if preflight["status"] != "PASS":
        raise ValidationFailure("Legacy project failed compatibility validation", preflight["errors"])

    candidate, input_migration, input_source = _load_migration_input(root, input_path)
    project_doc, lock_doc = _assert_project_identity(root, candidate)
    readiness = validate_project_input(candidate, require_approvals=True)
    if readiness["status"] == "WAITING_INPUT":
        raise WaitingInput("Project input must be completed before migration", readiness)
    if readiness["status"] == "WAITING_DECISION":
        raise WaitingDecision("Explicit project approvals are required before migration", readiness)
    if readiness["status"] != "READY_FOR_HANDOFF":
        raise ValidationFailure("Project input cannot be migrated", readiness)

    migrated_at = utc_now()
    project = project_doc["project"]
    legacy_lock_digest = f"sha256:{sha256_file(lock_path)}"
    legacy_input_path = root / ".harness/state/PROJECT_INPUT_ACCEPTED.yaml"
    legacy_input_digest = f"sha256:{sha256_file(legacy_input_path)}"

    task_mappings = _migrate_current_task_revisions(root, migrated_at)
    brownfield = _migrate_brownfield_baseline(root, project, candidate, migrated_at)
    versions, digests = _copy_current_registries(root)
    _copy_runtime(root)

    lock = lock_doc["project_lock"]
    migrations = list(lock.get("migrations_applied") or [])
    if PROJECT_INPUT_MIGRATION_ID not in migrations:
        migrations.append(PROJECT_INPUT_MIGRATION_ID)
    lock.update(
        {
            "harness_distribution": ENGINE_VERSION,
            "schema_version": SCHEMA_VERSION,
            "registry_versions": versions,
            "registry_digests": digests,
            "migrations_applied": migrations,
            "migrated_from": LEGACY_ENGINE_VERSION,
            "migrated_from_schema_version": LEGACY_SCHEMA_VERSION,
            "migrated_at": migrated_at,
        }
    )
    write_data(lock_path, lock_doc)

    project["harness_schema_version"] = SCHEMA_VERSION
    write_data(root / ".harness/config/PROJECT.yaml", project_doc)
    write_data(legacy_input_path, candidate)

    state_doc = load_data(state_path)
    state_doc["state"]["updated_at"] = migrated_at
    write_data(state_path, state_doc)
    render_roadmap(root)
    render_status(root)
    human_views = _update_human_views(root, migrated_at)

    report = {
        "migration_report": {
            "id": PROJECT_INPUT_MIGRATION_ID,
            "status": "COMPLETED",
            "project_ref": project.get("id"),
            "from": {"engine": LEGACY_ENGINE_VERSION, "schema_version": LEGACY_SCHEMA_VERSION},
            "to": {"engine": ENGINE_VERSION, "schema_version": SCHEMA_VERSION},
            "migrated_at": migrated_at,
            "input_source": input_source,
            "input_migration": input_migration,
            "legacy_lock_digest": legacy_lock_digest,
            "legacy_input_digest": legacy_input_digest,
            "historical_task_files_rewritten": False,
            "historical_run_files_rewritten": False,
            "task_status_revisions": task_mappings,
            "brownfield_approval": brownfield,
            "human_views_updated": human_views,
            "manifest_policy": "PRESERVE_INITIAL_HANDOFF_MANIFEST; VALIDATE_MUTABLE_STATE_WITH_VALIDATE_PROJECT",
        }
    }
    write_data(root / MIGRATION_REPORT_PATH, report)
    append_jsonl(
        root / ".harness/events/EVENTS.jsonl",
        {
            "type": "PROJECT_MIGRATED",
            "migration_id": PROJECT_INPUT_MIGRATION_ID,
            "from_engine": LEGACY_ENGINE_VERSION,
            "to_engine": ENGINE_VERSION,
            "at": migrated_at,
        },
    )

    validation = validate_handoff_directory(root, check_manifest=False, check_control_plane_state=True)
    if validation["status"] != "PASS":
        raise ValidationFailure("Migrated project failed v0.4.1 validation", validation["errors"])
    return {
        "status": "MIGRATED",
        "migration_id": PROJECT_INPUT_MIGRATION_ID,
        "project": str(root),
        "engine_version": ENGINE_VERSION,
        "schema_version": SCHEMA_VERSION,
        "report_path": MIGRATION_REPORT_PATH,
        "task_status_revisions": task_mappings,
        "brownfield_approval": brownfield,
        "validation_status": validation["status"],
    }
