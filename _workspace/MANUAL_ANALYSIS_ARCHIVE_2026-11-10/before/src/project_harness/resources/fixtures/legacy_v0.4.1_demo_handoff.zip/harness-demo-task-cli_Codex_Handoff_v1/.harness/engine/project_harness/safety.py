from __future__ import annotations

import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import zipfile

from .errors import SafetyViolation, ValidationFailure

DEFAULT_EXCLUDED_DIRS = {
    ".git",
    ".harness",
    "node_modules",
    ".venv",
    "venv",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "dist",
    "build",
}
DEFAULT_EXCLUDED_FILES = {".DS_Store"}


def _safe_zip_member(name: str) -> PurePosixPath:
    normalized = name.replace("\\", "/")
    path = PurePosixPath(normalized)
    if path.is_absolute() or ".." in path.parts or not path.parts:
        raise SafetyViolation("Unsafe ZIP entry", name)
    # Drive-letter paths are not absolute to PurePosixPath.
    if ":" in path.parts[0]:
        raise SafetyViolation("Unsafe ZIP entry", name)
    return path


def inspect_zip(path: Path) -> list[zipfile.ZipInfo]:
    try:
        with zipfile.ZipFile(path) as zf:
            infos = zf.infolist()
            for info in infos:
                _safe_zip_member(info.filename)
                mode = (info.external_attr >> 16) & 0xFFFF
                if stat.S_ISLNK(mode):
                    raise SafetyViolation("ZIP symlinks are not allowed", info.filename)
            bad = zf.testzip()
            if bad:
                raise ValidationFailure("ZIP CRC validation failed", bad)
            return infos
    except zipfile.BadZipFile as exc:
        raise ValidationFailure("Invalid ZIP archive", str(path)) from exc


def safe_extract_zip(path: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path) as zf:
        for info in zf.infolist():
            member = _safe_zip_member(info.filename)
            mode = (info.external_attr >> 16) & 0xFFFF
            if stat.S_ISLNK(mode):
                raise SafetyViolation("ZIP symlinks are not allowed", info.filename)
            target = (destination / Path(*member.parts)).resolve()
            try:
                target.relative_to(destination.resolve())
            except ValueError as exc:
                raise SafetyViolation("ZIP entry escapes destination", info.filename) from exc
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst)


def detect_single_root(directory: Path) -> Path:
    children = [p for p in directory.iterdir() if p.name not in {"__MACOSX", ".DS_Store"}]
    if len(children) == 1 and children[0].is_dir():
        return children[0]
    return directory


def copy_tree_filtered(
    source: Path,
    destination: Path,
    *,
    excluded_dirs: set[str] | None = None,
    excluded_files: set[str] | None = None,
) -> None:
    excluded_dirs = DEFAULT_EXCLUDED_DIRS if excluded_dirs is None else excluded_dirs
    excluded_files = DEFAULT_EXCLUDED_FILES if excluded_files is None else excluded_files
    source = source.resolve()
    destination.mkdir(parents=True, exist_ok=True)
    for current, dirs, files in os.walk(source):
        dirs[:] = sorted(
            d
            for d in dirs
            if d not in excluded_dirs and not (Path(current) / d).is_symlink()
        )
        base = Path(current)
        rel_dir = base.relative_to(source)
        target_dir = destination / rel_dir
        target_dir.mkdir(parents=True, exist_ok=True)
        for name in sorted(files):
            if name in excluded_files:
                continue
            src = base / name
            if src.is_symlink():
                continue
            dst = target_dir / name
            shutil.copy2(src, dst)


def repository_source_to_directory(source: Path, temporary_root: Path) -> Path:
    source = source.expanduser().resolve()
    if source.is_dir():
        return source
    if source.is_file() and source.suffix.lower() == ".zip":
        extracted = temporary_root / "repository-extracted"
        safe_extract_zip(source, extracted)
        return detect_single_root(extracted)
    raise ValidationFailure(
        "Repository source must be a directory or ZIP archive",
        str(source),
    )
