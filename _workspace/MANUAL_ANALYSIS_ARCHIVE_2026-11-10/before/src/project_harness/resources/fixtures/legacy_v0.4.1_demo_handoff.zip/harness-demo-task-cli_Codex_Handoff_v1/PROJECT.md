# Harness Demo Task CLI

## Принятая цель

A user needs a tiny local command-line task list without network dependencies.

## Первый проверяемый результат

The user can add, list and complete tasks stored in a local JSON file.

## Профиль

`PRF-CLI-TOOL@1` — The accepted first outcome is a local command-line tool.

## Пользователи

- Local CLI user

## В scope

- Add a task
- List tasks
- Mark a task complete
- Persist tasks locally

## Вне scope

- User accounts
- Cloud synchronization
- Web interface
- Network services

## Критерии успеха

- Automated tests cover add and list behavior
- A later task adds and tests completion behavior
- README documents commands

## Ограничения

### Обязательные

- Use only the Python standard library
- Work without internet

### Запрещённые

- External service calls
- Provider billing or token accounting

### Нефункциональные

- Deterministic tests
- Human-readable local data

## Допущения

- A single local process writes the task file

## Неизвестные

- Нет
