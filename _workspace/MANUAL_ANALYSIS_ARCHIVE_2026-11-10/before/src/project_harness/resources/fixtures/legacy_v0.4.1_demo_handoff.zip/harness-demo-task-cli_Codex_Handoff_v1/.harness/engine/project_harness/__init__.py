"""Project Harness — deterministic preparation and governed Codex handoff runtime."""

__version__ = "0.4.1"
