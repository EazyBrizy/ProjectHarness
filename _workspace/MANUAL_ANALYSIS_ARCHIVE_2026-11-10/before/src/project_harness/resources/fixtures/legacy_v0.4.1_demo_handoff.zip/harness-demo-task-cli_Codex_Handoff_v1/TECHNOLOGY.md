# Technology Baseline

**Статус:** ACCEPTED

## Selections

- **LANGUAGE**: Python >=3.11 — Portable standard library and simple test loop
- **TEST_FRAMEWORK**: unittest stdlib — No external dependencies

## Build commands

- `python -m py_compile task_cli.py`

## Test commands

- `python -m unittest discover -s tests -v`

## Lint commands

- Нет
