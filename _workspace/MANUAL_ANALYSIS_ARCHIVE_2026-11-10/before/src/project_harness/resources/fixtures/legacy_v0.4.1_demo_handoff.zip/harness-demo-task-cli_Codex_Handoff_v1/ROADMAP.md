# Roadmap

Harness Core использует один активный task; зависимости остаются причинным DAG.

## WP-HARNESS-DEMO-TASK-CLI-001 — Deliver the local task CLI

**Статус:** `READY`

Provide the accepted add/list/done user outcome with deterministic tests and documentation.

- `TSK-HARNESS-DEMO-TASK-CLI-001` — **READY** — Implement add and list commands
  - depends on: нет
  - expected: task_cli.py supports add and list, tests pass and README contains usage.
- `TSK-HARNESS-DEMO-TASK-CLI-002` — **PLANNED** — Implement done command
  - depends on: TSK-HARNESS-DEMO-TASK-CLI-001
  - expected: done marks a task complete and tests cover persisted completion state.
