from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import sys
import tempfile
from typing import Any

from .compiler import prepare_handoff
from .errors import HarnessError, ValidationFailure
from .intake import check_intake, start_intake
from .migration import migrate_project
from .resources import distribution_root
from .runtime import block_current, complete_current, next_task, project_status, resume_blocked, verify_current
from .serialization import load_data, write_data
from .util import ENGINE_VERSION
from .validation import doctor, validate_handoff, validate_project_directory


def _emit(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=False))


def _exit_for_status(status: str | None) -> int:
    if status in {"WAITING_INPUT", "WAITING_DECISION", "BLOCKED"}:
        return 3
    if status in {"FAIL", "FAILED", "INVALID"}:
        return 2
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="project-harness",
        description="Project Harness v0.4.1 — Browser GPT preparation and governed Codex handoff runtime.",
    )
    parser.add_argument("--version", action="version", version=ENGINE_VERSION)
    sub = parser.add_subparsers(dest="command", required=True)

    doctor_parser = sub.add_parser("doctor", help="Validate distribution registries, schemas, skills and manifest.")
    doctor_parser.add_argument("--root", type=Path)
    doctor_parser.add_argument("--skip-manifest", action="store_true")

    start = sub.add_parser("start-intake", help="Create an external provisional intake workspace without modifying the target repository.")
    start.add_argument("--workspace", type=Path, required=True)
    start.add_argument("--project-name", required=True)
    start.add_argument("--mode", choices=["greenfield", "brownfield", "hybrid", "GREENFIELD", "BROWNFIELD", "HYBRID"], required=True)
    start.add_argument("--source", type=Path, action="append", default=[])
    start.add_argument("--repository", type=Path)
    start.add_argument("--input", type=Path)
    start.add_argument("--force", action="store_true")

    check = sub.add_parser("check-intake", help="Validate PROJECT_INPUT.yaml and regenerate missing questions/readiness.")
    check.add_argument("--workspace", type=Path, required=True)

    prepare = sub.add_parser("prepare", help="Compile a validated Codex Handoff ZIP from an approved intake workspace.")
    prepare.add_argument("--workspace", type=Path, required=True)
    prepare.add_argument("--output", type=Path, required=True)
    prepare.add_argument("--keep-directory", type=Path)

    validate = sub.add_parser("validate-handoff", help="Validate an immutable initial handoff directory or ZIP, including its baseline manifest.")
    validate.add_argument("--project", type=Path, required=True, help="Handoff root directory or ZIP archive.")

    validate_project = sub.add_parser("validate-project", help="Validate mutable project state after Codex execution without enforcing the original handoff manifest.")
    validate_project.add_argument("--project", type=Path, required=True, help="Extracted handoff/project root directory.")

    migrate = sub.add_parser("migrate-project", help="Migrate an extracted v0.4.0 project to v0.4.1 without rewriting immutable history.")
    migrate.add_argument("--project", type=Path, required=True, help="Extracted v0.4.0 project root directory.")
    migrate.add_argument("--input", type=Path, help="Optional PROJECT_INPUT@2 that differs only by explicit Brownfield approval.")

    status = sub.add_parser("status", help="Show persisted project/task/run state.")
    status.add_argument("--project", type=Path, required=True)

    nxt = sub.add_parser("next", help="Return or JIT-compile the current READY task bundle.")
    nxt.add_argument("--project", type=Path, required=True)

    verify = sub.add_parser("verify", help="Independently check actual writes, expected paths and declared verification commands.")
    verify.add_argument("--project", type=Path, required=True)
    verify.add_argument("--allow-command-execution", action="store_true")

    complete = sub.add_parser("complete", help="Accept a PASS-verified Agent Task Result and transition to the next task.")
    complete.add_argument("--project", type=Path, required=True)
    complete.add_argument("--result", type=Path, required=True)

    block = sub.add_parser("block", help="Record a material blocker and safe recovery routes.")
    block.add_argument("--project", type=Path, required=True)
    block.add_argument("--reason", required=True)
    block.add_argument("--option", action="append", default=[])

    resume = sub.add_parser("resume", help="Resolve an OPEN blocker and compile a new run attempt.")
    resume.add_argument("--project", type=Path, required=True)
    resume.add_argument("--resolution", required=True)
    resume.add_argument("--blocker")

    demo = sub.add_parser("demo", help="Build the bundled greenfield handoff fixture.")
    demo.add_argument("--output-dir", type=Path, required=True)
    demo.add_argument("--keep-directory", action="store_true")
    return parser


def _demo(output_dir: Path, keep: bool) -> dict[str, Any]:
    root = distribution_root()
    fixture = root / "fixtures/demo_project_input.json"
    if not fixture.exists():
        raise ValidationFailure("Bundled demo fixture is missing", str(fixture))
    output_dir = output_dir.expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    workspace = output_dir / "demo-intake"
    if workspace.exists():
        shutil.rmtree(workspace)
    start_intake(
        workspace,
        project_name="Harness Demo Task CLI",
        mode="GREENFIELD",
        initial_input=fixture,
        force=True,
    )
    output = output_dir / "harness-demo-codex-handoff.zip"
    keep_directory = output_dir / "harness-demo-codex-handoff" if keep else None
    return prepare_handoff(workspace, output, keep_directory=keep_directory)


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "doctor":
            result = doctor(args.root, check_manifest=not args.skip_manifest)
        elif args.command == "start-intake":
            result = start_intake(
                args.workspace,
                project_name=args.project_name,
                mode=args.mode,
                sources=args.source,
                repository=args.repository,
                initial_input=args.input,
                force=args.force,
            )
        elif args.command == "check-intake":
            result = check_intake(args.workspace)
        elif args.command == "prepare":
            result = prepare_handoff(args.workspace, args.output, keep_directory=args.keep_directory)
        elif args.command == "validate-handoff":
            result = validate_handoff(args.project)
        elif args.command == "validate-project":
            result = validate_project_directory(args.project)
        elif args.command == "migrate-project":
            result = migrate_project(args.project, input_path=args.input)
        elif args.command == "status":
            result = project_status(args.project)
        elif args.command == "next":
            result = next_task(args.project)
        elif args.command == "verify":
            result = verify_current(args.project, allow_command_execution=args.allow_command_execution)
        elif args.command == "complete":
            result = complete_current(args.project, args.result)
        elif args.command == "block":
            result = block_current(args.project, args.reason, options=args.option or None)
        elif args.command == "resume":
            result = resume_blocked(args.project, resolution=args.resolution, blocker_ref=args.blocker)
        elif args.command == "demo":
            result = _demo(args.output_dir, args.keep_directory)
        else:  # pragma: no cover
            parser.error("unknown command")
            return 2
        _emit(result)
        return _exit_for_status(result.get("status") if isinstance(result, dict) else None)
    except HarnessError as exc:
        payload = {
            "status": exc.code,
            "message": exc.message,
            "details": exc.details,
        }
        _emit(payload)
        return exc.exit_code
    except KeyboardInterrupt:
        _emit({"status": "CANCELLED", "message": "Interrupted"})
        return 130
    except Exception as exc:  # Last-resort structured failure; never fabricate success.
        _emit({"status": "INTERNAL_ERROR", "message": str(exc), "type": type(exc).__name__})
        return 70


if __name__ == "__main__":
    raise SystemExit(main())
