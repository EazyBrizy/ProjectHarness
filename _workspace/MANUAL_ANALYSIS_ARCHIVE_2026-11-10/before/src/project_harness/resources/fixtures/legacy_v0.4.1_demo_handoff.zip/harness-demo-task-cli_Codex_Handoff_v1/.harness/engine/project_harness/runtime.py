from __future__ import annotations

from copy import deepcopy
import os
from pathlib import Path
import shlex
import subprocess
from typing import Any

from .errors import HarnessError, SafetyViolation, ValidationFailure
from .prompting import ensure_current_project_contract, reserve_run
from .render import render_roadmap, render_status
from .serialization import append_jsonl, load_data, write_data
from .util import resolve_inside, utc_now
from .workspace import (
    assert_agent_result_unchanged,
    check_control_plane,
    diff_snapshots,
    record_phase_boundary,
    secure_read_agent_result,
    snapshot_product,
    validate_scope,
)

RESULT_STATUSES = {"COMPLETED", "BLOCKED", "FAILED"}
SHELL_META = {"|", "||", "&&", ";", ">", ">>", "<", "2>", "&"}
SAFETY_RECOVERY_ROUTE = "RESTORE_CONTROL_PLANE_FROM_TRUSTED_HANDOFF_OR_RESTART_RUN"


def _state(root: Path) -> tuple[Path, dict[str, Any]]:
    path = root / ".harness/state/CURRENT_STATE.yaml"
    if not path.exists():
        raise ValidationFailure("Project Harness state is missing", str(path))
    value = load_data(path)
    if not isinstance(value, dict) or not isinstance(value.get("state"), dict):
        raise ValidationFailure("Project Harness state envelope is invalid", str(path))
    return path, value


def _task(root: Path, task_id: str) -> tuple[dict[str, Any], str]:
    index = load_data(root / ".harness/tasks/INDEX.yaml")["task_index"]
    rel = index["current"].get(task_id)
    if not rel:
        raise ValidationFailure("Unknown task", task_id)
    value = load_data(root / rel)
    task = value.get("task") if isinstance(value, dict) else None
    if not isinstance(task, dict):
        raise ValidationFailure("Task contract envelope is invalid", rel)
    return task, rel


def _write_task_revision(root: Path, task_id: str, **changes: Any) -> dict[str, Any]:
    index_path = root / ".harness/tasks/INDEX.yaml"
    index_doc = load_data(index_path)
    index = index_doc["task_index"]
    current_rel = index["current"][task_id]
    task = load_data(root / current_rel)["task"]
    previous_ref = f"{task['id']}@{task['revision']}"
    task.update(changes)
    task["revision"] = int(task["revision"]) + 1
    task["previous_revision_ref"] = previous_ref
    task["updated_at"] = utc_now()
    new_rel = f".harness/tasks/{task_id}@{task['revision']}.yaml"
    write_data(root / new_rel, {"task": task})
    index["current"][task_id] = new_rel
    write_data(index_path, index_doc)
    return task


def _write_trusted_task_revision(root: Path, trusted_task: dict[str, Any], **changes: Any) -> dict[str, Any]:
    """Create a blocked revision without trusting a possibly modified current task file."""
    task = deepcopy(trusted_task)
    task_id = str(task["id"])
    previous_ref = f"{task_id}@{task['revision']}"
    task.update(changes)
    revision = int(task["revision"]) + 1
    while (root / f".harness/tasks/{task_id}@{revision}.yaml").exists():
        revision += 1
    task["revision"] = revision
    task["previous_revision_ref"] = previous_ref
    task["updated_at"] = utc_now()
    new_rel = f".harness/tasks/{task_id}@{revision}.yaml"
    write_data(root / new_rel, {"task": task})

    index_path = root / ".harness/tasks/INDEX.yaml"
    try:
        index_doc = load_data(index_path)
        index = index_doc.get("task_index")
        if not isinstance(index, dict):
            raise ValueError("task_index envelope is missing")
        current = index.setdefault("current", {})
        current[task_id] = new_rel
        order = index.setdefault("order", [])
        if task_id not in order:
            order.append(task_id)
    except Exception:
        index_doc = {"task_index": {"order": [task_id], "current": {task_id: new_rel}, "aliases": {}}}
    write_data(index_path, index_doc)
    return task


def _write_work_package_revision(root: Path, wp_id: str, status: str) -> dict[str, Any]:
    index_path = root / ".harness/work-packages/INDEX.yaml"
    index_doc = load_data(index_path)
    index = index_doc["work_package_index"]
    current_rel = index["current"][wp_id]
    wp = load_data(root / current_rel)["work_package"]
    if wp.get("status") == status:
        return wp
    previous_ref = f"{wp['id']}@{wp['revision']}"
    wp["revision"] = int(wp["revision"]) + 1
    wp["previous_revision_ref"] = previous_ref
    wp["status"] = status
    wp["updated_at"] = utc_now()
    new_rel = f".harness/work-packages/{wp_id}@{wp['revision']}.yaml"
    write_data(root / new_rel, {"work_package": wp})
    index["current"][wp_id] = new_rel
    write_data(index_path, index_doc)
    return wp


def project_status(root: Path) -> dict[str, Any]:
    root = root.expanduser().resolve()
    _, state_doc = _state(root)
    state = state_doc["state"]
    task_summary = None
    if state.get("current_task_ref"):
        task, rel = _task(root, state["current_task_ref"])
        task_summary = {
            "task_ref": f"{task['id']}@{task['revision']}",
            "title": task["title"],
            "status": task["status"],
            "path": rel,
        }
    return {
        "status": state.get("project_status"),
        "handoff_status": state.get("handoff_status"),
        "project_ref": state.get("project_ref"),
        "current_task": task_summary,
        "active_run": state.get("active_run"),
        "completed_task_refs": state.get("completed_task_refs") or [],
        "blocked_task_refs": state.get("blocked_task_refs") or [],
        "next_route": state.get("next_route"),
    }


def next_task(root: Path) -> dict[str, Any]:
    root = root.expanduser().resolve()
    _, state_doc = _state(root)
    state = state_doc["state"]
    if state.get("project_status") == "COMPLETED":
        return {"status": "PROJECT_COMPLETED", "next_route": "NONE"}
    if state.get("blocked_task_refs") and not state.get("active_run"):
        return {
            "status": "BLOCKED",
            "task_ref": state.get("current_task_ref"),
            "blocker_refs": state.get("open_blocker_refs") or [],
            "next_route": state.get("next_route") or "RESOLVE_BLOCKER_OR_CHANGE_SCOPE",
        }
    return reserve_run(root, state.get("current_task_ref"))


def _normalize_command(item: Any, default_timeout: int) -> tuple[list[str], Path | str, int]:
    if isinstance(item, str):
        argv = shlex.split(item)
        cwd: str = "."
        timeout = default_timeout
    elif isinstance(item, dict):
        raw = item.get("argv") or item.get("command")
        if isinstance(raw, str):
            argv = shlex.split(raw)
        elif isinstance(raw, list):
            argv = [str(part) for part in raw]
        else:
            raise ValidationFailure("Verification command requires argv or command", item)
        cwd = str(item.get("cwd", "."))
        timeout = int(item.get("timeout_seconds", default_timeout))
    else:
        raise ValidationFailure("Unsupported verification command", item)
    if not argv:
        raise ValidationFailure("Empty verification command")
    if any(token in SHELL_META for token in argv):
        raise SafetyViolation("Shell control operators are not allowed; commands run without a shell", argv)
    if timeout < 1 or timeout > 1800:
        raise ValidationFailure("Verification timeout must be between 1 and 1800 seconds", timeout)
    return argv, cwd, timeout


def _sanitized_env() -> dict[str, str]:
    allowed_exact = {
        "PATH", "HOME", "USER", "USERNAME", "LANG", "LC_ALL", "TMPDIR", "TEMP", "TMP",
        "SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT", "PYTHONPATH", "VIRTUAL_ENV",
    }
    env = {key: value for key, value in os.environ.items() if key in allowed_exact or key.startswith("LC_")}
    env.update(
        {
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONUNBUFFERED": "1",
            "CI": "1",
            "NO_COLOR": "1",
        }
    )
    return env


def _run_command(root: Path, item: Any, default_timeout: int) -> dict[str, Any]:
    argv, cwd_value, timeout = _normalize_command(item, default_timeout)
    cwd = resolve_inside(root, cwd_value)
    if not cwd.is_dir():
        raise ValidationFailure("Verification cwd does not exist", str(cwd_value))
    started = utc_now()
    try:
        completed = subprocess.run(
            argv,
            cwd=cwd,
            env=_sanitized_env(),
            shell=False,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        return {
            "argv": argv,
            "cwd": cwd.relative_to(root).as_posix() or ".",
            "started_at": started,
            "completed_at": utc_now(),
            "returncode": completed.returncode,
            "stdout": completed.stdout[-20000:],
            "stderr": completed.stderr[-20000:],
            "status": "PASS" if completed.returncode == 0 else "FAIL",
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "argv": argv,
            "cwd": cwd.relative_to(root).as_posix() or ".",
            "started_at": started,
            "completed_at": utc_now(),
            "returncode": None,
            "stdout": (exc.stdout or "")[-20000:] if isinstance(exc.stdout, str) else "",
            "stderr": (exc.stderr or "")[-20000:] if isinstance(exc.stderr, str) else "",
            "status": "TIMEOUT",
        }
    except OSError as exc:
        return {
            "argv": argv,
            "cwd": cwd.relative_to(root).as_posix() or ".",
            "started_at": started,
            "completed_at": utc_now(),
            "returncode": None,
            "stdout": "",
            "stderr": str(exc),
            "status": "ERROR",
        }


def _snapshot(root: Path, active: dict[str, Any]) -> dict[str, Any]:
    value = load_data(root / active["snapshot_path"])
    snapshot = value.get("snapshot") if isinstance(value, dict) else None
    if not isinstance(snapshot, dict):
        raise ValidationFailure("Run snapshot envelope is invalid", active.get("snapshot_path"))
    return snapshot


def _trusted_task(root: Path, active: dict[str, Any]) -> dict[str, Any]:
    snapshot = _snapshot(root, active)
    trusted = snapshot.get("trusted_task_contract")
    if isinstance(trusted, dict) and trusted.get("id"):
        return deepcopy(trusted)
    task_id = str(active["task_ref"]).split("@")[0]
    task, _ = _task(root, task_id)
    return deepcopy(task)


def _next_blocker_id(root: Path, task_id: str) -> str:
    token = task_id.removeprefix("TSK-").rsplit("-", 1)[0] or "PROJECT"
    sequence = len(list((root / ".harness/blockers").glob("BLK-*@1.yaml"))) + 1
    return f"BLK-{token}-{sequence:03d}"


def _safety_block(
    root: Path,
    state_path: Path,
    state_doc: dict[str, Any],
    active: dict[str, Any],
    details: dict[str, Any],
    *,
    command_results: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Block a run using the trusted snapshot, never the modified Task Contract."""
    state = state_doc["state"]
    trusted_task = _trusted_task(root, active)
    task_id = str(trusted_task["id"])
    run_ref = str(active["run_ref"])
    suffix = run_ref.removeprefix("RUN-")
    evidence_id = f"EVD-{suffix}-SAFETY"
    report_id = f"VAL-{suffix}-SAFETY"
    blocker_id = _next_blocker_id(root, task_id)
    recorded_at = utc_now()
    command_results = list(command_results or [])
    commands_gate = "EXECUTED_BEFORE_DETECTION" if command_results else "NOT_RUN"
    reason = "Protected Project Harness control plane changed after Run reservation"
    recovery = [
        "Restore the project from the trusted handoff archive and start a new Run attempt",
        "Discard the modified control plane and re-run prepare from accepted input",
        "Cancel the route and inspect the safety evidence",
    ]

    evidence_path = f".harness/evidence/{evidence_id}.yaml"
    write_data(
        root / evidence_path,
        {
            "verification_evidence": {
                "id": evidence_id,
                "kind": "SAFETY_VIOLATION",
                "task_ref": active["task_ref"],
                "run_ref": run_ref,
                "status": "BLOCKED",
                "gates": {"control_plane": "FAIL", "commands": commands_gate},
                "control_plane": details,
                "commands": command_results,
                "created_at": recorded_at,
            }
        },
    )
    report_path = f".harness/reports/{report_id}.yaml"
    write_data(
        root / report_path,
        {
            "validation_report": {
                "id": report_id,
                "kind": "CONTROL_PLANE_SAFETY",
                "task_ref": active["task_ref"],
                "run_ref": run_ref,
                "evidence_ref": evidence_id,
                "status": "BLOCKED",
                "gates": {"control_plane": "FAIL", "commands": commands_gate},
                "control_plane": details,
                "command_results": command_results,
                "created_at": recorded_at,
            }
        },
    )
    blocker = {
        "id": blocker_id,
        "revision": 1,
        "kind": "SAFETY_VIOLATION",
        "task_ref": active["task_ref"],
        "run_ref": run_ref,
        "reason": reason,
        "evidence_ref": evidence_id,
        "validation_report_ref": report_id,
        "recovery_options": recovery,
        "resume_condition": "Restore a trusted handoff/control plane and create a new Run attempt; in-place resume is prohibited.",
        "status": "OPEN",
        "created_at": recorded_at,
    }
    write_data(root / f".harness/blockers/{blocker_id}@1.yaml", {"blocker": blocker})
    run = {
        "id": run_ref,
        "task_ref": active["task_ref"],
        "attempt_no": active["attempt_no"],
        "run_plan_ref": active["run_plan_ref"],
        "status": "BLOCKED",
        "failure_class": "CONTROL_PLANE_TAMPERING",
        "blocker_ref": blocker_id,
        "evidence_refs": [evidence_id],
        "verification_report_ref": report_id,
        "compensation_status": "NOT_REQUIRED",
        "completed_at": recorded_at,
    }
    write_data(root / f".harness/runtime/RUNS/{run_ref}.yaml", {"run": run})
    blocked_task = _write_trusted_task_revision(
        root,
        trusted_task,
        status="BLOCKED",
        blocker_ref=blocker_id,
        blocked_at=recorded_at,
    )
    blocked_ref = f"{blocked_task['id']}@{blocked_task['revision']}"

    state["active_run"] = None
    state.setdefault("blocked_task_refs", []).append(blocked_ref)
    state.setdefault("open_blocker_refs", []).append(blocker_id)
    state["current_task_ref"] = task_id
    state["project_status"] = "BLOCKED"
    state["next_route"] = SAFETY_RECOVERY_ROUTE
    state["last_safety_violation_ref"] = report_id
    state["updated_at"] = recorded_at
    write_data(state_path, state_doc)
    write_data(
        root / ".harness/state/NEXT_TASK.yaml",
        {
            "next_task": {
                "status": "BLOCKED",
                "task_ref": blocked_ref,
                "run_ref": run_ref,
                "blocker_ref": blocker_id,
                "next_route": SAFETY_RECOVERY_ROUTE,
                "recovery_options": recovery,
            }
        },
    )
    append_jsonl(
        root / ".harness/events/EVENTS.jsonl",
        {
            "type": "SAFETY_VIOLATION",
            "task_ref": active["task_ref"],
            "run_ref": run_ref,
            "blocker_ref": blocker_id,
            "evidence_ref": evidence_id,
            "at": recorded_at,
        },
    )
    try:
        _update_wp_status(root, str(trusted_task["work_package_ref"]))
        render_roadmap(root)
    except Exception:
        # A safety transition must remain reportable even when a protected
        # aggregate/index was itself the tampering target.
        pass
    render_status(root)
    return {
        "status": "BLOCKED",
        "reason": "SAFETY_VIOLATION",
        "task_ref": blocked_ref,
        "run_ref": run_ref,
        "blocker_ref": blocker_id,
        "report_ref": report_id,
        "evidence_ref": evidence_id,
        "next_route": SAFETY_RECOVERY_ROUTE,
        "control_plane": details,
        "commands": command_results,
    }


def verify_current(root: Path, *, allow_command_execution: bool = False) -> dict[str, Any]:
    root = root.expanduser().resolve()
    state_path, state_doc = _state(root)
    state = state_doc["state"]
    active = state.get("active_run")
    if not isinstance(active, dict):
        raise ValidationFailure("No active run to verify")

    control_plane = check_control_plane(root, active, allow_missing_agent_result=True)
    if control_plane.get("status") != "PASS":
        return _safety_block(root, state_path, state_doc, active, control_plane)

    task_id = str(active["task_ref"]).split("@")[0]
    task, _ = _task(root, task_id)
    snapshot_doc = _snapshot(root, active)
    before = snapshot_doc.get("product_files") or snapshot_doc.get("files") or {}
    verification = task.get("verification") or {}
    commands = verification.get("commands") or []
    command_results: list[dict[str, Any]] = []
    command_gate = "PASS"
    if commands and not allow_command_execution:
        command_gate = "BLOCKED"
    elif allow_command_execution:
        for command in commands:
            result = _run_command(root, command, int(verification.get("timeout_seconds", 300)))
            command_results.append(result)
        if any(item["status"] != "PASS" for item in command_results):
            command_gate = "FAIL"

    # Verification commands execute product code and can therefore attempt a
    # control-plane write. Re-check before the Kernel creates any evidence or
    # advances the phase boundary so such writes cannot be sealed as trusted.
    post_command_control_plane = check_control_plane(root, active, allow_missing_agent_result=True)
    if post_command_control_plane.get("status") != "PASS":
        post_command_control_plane["detected_after_verification_commands"] = bool(command_results)
        return _safety_block(
            root,
            state_path,
            state_doc,
            active,
            post_command_control_plane,
            command_results=command_results,
        )

    after = snapshot_product(root)
    diff = diff_snapshots(before, after)
    scope = validate_scope(diff, task["scope"])
    expected_paths = [str(item) for item in verification.get("expected_paths") or []]
    missing_paths: list[str] = []
    for relative in expected_paths:
        try:
            path = resolve_inside(root, relative)
        except HarnessError as exc:
            missing_paths.append(f"unsafe:{relative}:{exc.code}")
            continue
        if not path.exists():
            missing_paths.append(relative)
    expected_gate = "PASS" if not missing_paths else "FAIL"
    manual_checks = verification.get("manual_checks") or []
    manual_gate = "PASS" if (not manual_checks or verification.get("allow_manual") is True) else "BLOCKED"
    gates = {
        "control_plane": "PASS",
        "scope": scope["status"],
        "commands": command_gate,
        "expected_paths": expected_gate,
        "manual_checks": manual_gate,
    }
    status = "PASS" if all(value == "PASS" for value in gates.values()) else ("BLOCKED" if "BLOCKED" in gates.values() else "FAIL")
    run_ref = active["run_ref"]
    report_id = f"VAL-{run_ref.removeprefix('RUN-')}"
    evidence_id = f"EVD-{run_ref.removeprefix('RUN-')}"
    recorded_at = utc_now()
    evidence = {
        "id": evidence_id,
        "task_ref": active["task_ref"],
        "run_ref": run_ref,
        "status": status,
        "gates": gates,
        "control_plane": control_plane,
        "scope_validation": scope,
        "diff": diff,
        "commands": command_results,
        "expected_paths": {"declared": expected_paths, "missing": missing_paths},
        "manual_checks": manual_checks,
        "created_at": recorded_at,
    }
    evidence_path = f".harness/evidence/{evidence_id}.yaml"
    write_data(root / evidence_path, {"verification_evidence": evidence})
    report = {
        "id": report_id,
        "kind": "TASK_VERIFICATION",
        "task_ref": active["task_ref"],
        "run_ref": run_ref,
        "evidence_ref": evidence_id,
        "status": status,
        "gates": gates,
        "control_plane": control_plane,
        "diff": diff,
        "scope_validation": scope,
        "command_results": command_results,
        "missing_expected_paths": missing_paths,
        "created_at": recorded_at,
    }
    report_path = f".harness/reports/{report_id}.yaml"
    write_data(root / report_path, {"validation_report": report})
    active["verification_report_ref"] = report_id
    active["verification_report_path"] = report_path
    active["verification_evidence_ref"] = evidence_id
    active["verification_evidence_path"] = evidence_path
    active["control_plane_phase"] = "VERIFIED"
    active["verified_product_diff"] = _actual_change_set(diff)
    # Preserve exact post-verification product digests, not only the path set.
    # A later edit to an already-modified path must force re-verification.
    active["verified_product_files"] = after
    state["next_route"] = "COMPLETE_TASK" if status == "PASS" else ("PROVIDE_MANUAL_VERIFICATION" if status == "BLOCKED" else "FIX_TASK_OR_BLOCK")
    state["updated_at"] = recorded_at
    write_data(state_path, state_doc)
    append_jsonl(root / ".harness/events/EVENTS.jsonl", {"type": "VERIFICATION_FINISHED", "run_ref": run_ref, "status": status, "at": recorded_at})
    render_status(root)
    boundary = record_phase_boundary(
        root,
        active,
        phase="VERIFIED",
        kernel_written_paths=[
            evidence_path,
            report_path,
            ".harness/state/CURRENT_STATE.yaml",
            ".harness/events/EVENTS.jsonl",
            "STATUS.md",
        ],
        recorded_at=recorded_at,
    )
    return {
        "status": status,
        "report_ref": report_id,
        "report_path": report_path,
        "gates": gates,
        "control_plane": control_plane,
        "phase_boundary_digest": boundary["boundary_digest"],
        "diff": diff,
        "commands": command_results,
        "missing_expected_paths": missing_paths,
    }


def _validate_agent_result(value: Any, active: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValidationFailure("Agent Task Result must be an object")
    required = ["schema_version", "task_ref", "run_ref", "status", "summary", "changes", "commands", "tests", "evidence", "blockers"]
    allowed = set(required) | {"notes"}
    missing = [field for field in required if field not in value]
    unknown = sorted(set(value) - allowed)
    if missing:
        raise ValidationFailure("Agent Task Result is missing fields", missing)
    if unknown:
        raise ValidationFailure("Agent Task Result contains unknown fields", unknown)
    if value.get("schema_version") != 1:
        raise ValidationFailure("Unsupported Agent Task Result schema", value.get("schema_version"))
    if value.get("task_ref") != active.get("task_ref") or value.get("run_ref") != active.get("run_ref"):
        raise ValidationFailure(
            "Agent Task Result references a different task/run",
            {
                "expected": {"task_ref": active.get("task_ref"), "run_ref": active.get("run_ref")},
                "actual": {"task_ref": value.get("task_ref"), "run_ref": value.get("run_ref")},
            },
        )
    if value.get("status") not in RESULT_STATUSES:
        raise ValidationFailure("Invalid Agent Task Result status", value.get("status"))
    if not isinstance(value.get("summary"), str) or not value["summary"].strip():
        raise ValidationFailure("Agent Task Result summary must be a non-empty string")
    changes = value.get("changes")
    if not isinstance(changes, dict) or set(changes) != {"added", "modified", "deleted"}:
        raise ValidationFailure("Agent Task Result changes must contain only added/modified/deleted")
    if any(not isinstance(changes.get(key), list) or any(not isinstance(item, str) for item in changes[key]) for key in ("added", "modified", "deleted")):
        raise ValidationFailure("Agent Task Result change lists must contain strings")
    for field in ("commands", "tests", "evidence", "blockers", "notes"):
        if field in value and not isinstance(value[field], list):
            raise ValidationFailure(f"Agent Task Result {field} must be an array")
    return value


def _actual_change_set(diff: dict[str, Any]) -> dict[str, list[str]]:
    return {key: sorted(str(item) for item in diff.get(key, [])) for key in ("added", "modified", "deleted")}


def _next_runnable(state: dict[str, Any], root: Path) -> str | None:
    completed = {str(ref).split("@")[0] for ref in state.get("completed_task_refs") or []}
    for task_id in state.get("task_order") or []:
        if task_id in completed:
            continue
        task, _ = _task(root, task_id)
        if task.get("status") == "BLOCKED":
            return None
        deps = set(task.get("depends_on_tasks") or [])
        if deps.issubset(completed):
            return task_id
    return None


def _update_wp_status(root: Path, wp_id: str) -> None:
    wp_index = load_data(root / ".harness/work-packages/INDEX.yaml")["work_package_index"]
    wp = load_data(root / wp_index["current"][wp_id])["work_package"]
    statuses = []
    for task_id in wp.get("mandatory_task_refs") or []:
        task, _ = _task(root, task_id)
        statuses.append(task.get("status"))
    if statuses and all(status == "DONE" for status in statuses):
        target = "COMPLETED"
    elif any(status == "BLOCKED" for status in statuses):
        target = "BLOCKED"
    elif any(status in {"READY", "CLAIMED", "RUNNING", "VERIFYING", "DONE"} for status in statuses):
        target = "IN_PROGRESS"
    else:
        target = "PLANNED"
    _write_work_package_revision(root, wp_id, target)


def _assert_verified_product_unchanged(root: Path, active: dict[str, Any]) -> dict[str, dict[str, Any]]:
    verified = active.get("verified_product_files")
    if not isinstance(verified, dict):
        raise ValidationFailure("Verified product snapshot is missing; run verify again")
    current = snapshot_product(root)
    if current != verified:
        raise ValidationFailure(
            "Project files changed after verification; run verify again",
            {"delta_since_verification": diff_snapshots(verified, current)},
        )
    return current


def _exact_result_relative(root: Path, result_path: Path, active: dict[str, Any]) -> str:
    expected = str(active.get("allowed_agent_output_path") or f".harness/runtime/AGENT_RESULTS/{active['run_ref']}.json")
    supplied = result_path.expanduser()
    if not supplied.is_absolute():
        supplied = root / supplied
    supplied_abs = Path(os.path.abspath(supplied))
    expected_abs = Path(os.path.abspath(root / expected))
    if supplied_abs != expected_abs:
        raise SafetyViolation(
            "Agent Task Result must use the exact active Run output path",
            {"expected": expected, "supplied": str(result_path)},
        )
    return expected


def complete_current(root: Path, result_path: Path) -> dict[str, Any]:
    root = root.expanduser().resolve()
    state_path, state_doc = _state(root)
    state = state_doc["state"]
    active = state.get("active_run")
    if not isinstance(active, dict):
        raise ValidationFailure("No active run to complete")
    expected_result_path = _exact_result_relative(root, result_path, active)

    control_plane = check_control_plane(root, active, allow_missing_agent_result=False)
    if control_plane.get("status") != "PASS":
        return _safety_block(root, state_path, state_doc, active, control_plane)
    raw_result, result_digest, result_metadata = secure_read_agent_result(root, expected_result_path)
    result = _validate_agent_result(raw_result, active)
    result_metadata["sha256"] = result_digest

    if result["status"] == "BLOCKED":
        assert_agent_result_unchanged(root, result_metadata)
        reason = (result.get("blockers") or ["Agent reported a blocker"])[0]
        return block_current(root, str(reason), options=["Resolve blocker and resume", "Change scope", "Defer task", "Cancel route"])
    if result["status"] == "FAILED":
        assert_agent_result_unchanged(root, result_metadata)
        return block_current(root, result.get("summary") or "Agent execution failed", options=["Fix and retry", "Change scope", "Use a different implementation route"])

    report_path = active.get("verification_report_path")
    if not report_path:
        raise ValidationFailure("Independent verification has not been run")
    report = load_data(root / report_path)["validation_report"]
    if report.get("status") != "PASS":
        raise ValidationFailure("Task cannot complete without PASS verification", report)
    snapshot_doc = _snapshot(root, active)
    before = snapshot_doc.get("product_files") or snapshot_doc.get("files") or {}
    verified_product_files = _assert_verified_product_unchanged(root, active)
    current_diff = diff_snapshots(before, verified_product_files)
    verified_diff = _actual_change_set(report["diff"])
    if _actual_change_set(current_diff) != verified_diff:
        raise ValidationFailure("Project files changed after verification; run verify again", {"verified": verified_diff, "current": current_diff})
    declared = _actual_change_set(result["changes"])
    if declared != verified_diff:
        raise ValidationFailure("Agent-declared changes do not match independently observed changes", {"declared": declared, "observed": verified_diff})

    # Close the two TOCTOU windows immediately before kernel-owned completion writes.
    control_plane = check_control_plane(root, active, allow_missing_agent_result=False)
    if control_plane.get("status") != "PASS":
        return _safety_block(root, state_path, state_doc, active, control_plane)
    assert_agent_result_unchanged(root, result_metadata)
    _assert_verified_product_unchanged(root, active)

    task_id = str(active["task_ref"]).split("@")[0]
    task, _ = _task(root, task_id)
    completed_at = utc_now()
    run = {
        "id": active["run_ref"],
        "task_ref": active["task_ref"],
        "attempt_no": active["attempt_no"],
        "run_plan_ref": active["run_plan_ref"],
        "status": "SUCCEEDED",
        "agent_result_path": expected_result_path,
        "agent_result_sha256": result_digest,
        "evidence_refs": [active["verification_evidence_ref"]],
        "verification_report_ref": active["verification_report_ref"],
        "actual_changes": verified_diff,
        "compensation_status": "NOT_REQUIRED",
        "completed_at": completed_at,
    }
    run_path = f".harness/runtime/RUNS/{run['id']}.yaml"
    write_data(root / run_path, {"run": run})
    task_report_id = f"TRP-{run['id'].removeprefix('RUN-')}"
    task_report = {
        "id": task_report_id,
        "task_ref": active["task_ref"],
        "run_ref": run["id"],
        "status": "COMPLETED",
        "summary": result["summary"],
        "changes": verified_diff,
        "verification_report_ref": active["verification_report_ref"],
        "evidence_refs": [active["verification_evidence_ref"]],
        "documentation_impact": task.get("documentation"),
        "completed_at": completed_at,
    }
    task_report_path = f".harness/reports/{task_report_id}.yaml"
    write_data(root / task_report_path, {"task_report": task_report})
    completed_task = _write_task_revision(root, task_id, status="DONE", completion_report_ref=task_report_id, completed_at=completed_at)
    completed_ref = f"{completed_task['id']}@{completed_task['revision']}"
    if completed_ref not in state.setdefault("completed_task_refs", []):
        state["completed_task_refs"].append(completed_ref)
    if task_report_id not in state.setdefault("task_report_refs", []):
        state["task_report_refs"].append(task_report_id)
    state["active_run"] = None
    _update_wp_status(root, task["work_package_ref"])
    next_id = _next_runnable(state, root)
    if next_id:
        next_task_value, _ = _task(root, next_id)
        if next_task_value.get("status") == "PLANNED":
            _write_task_revision(root, next_id, status="READY", ready_at=completed_at)
        state["current_task_ref"] = next_id
        state["next_route"] = "COMPILE_NEXT_READY_TASK"
        state["project_status"] = "ACTIVE"
    else:
        state["current_task_ref"] = None
        state["next_route"] = "NONE"
        state["project_status"] = "COMPLETED"
        state["handoff_status"] = "EXECUTION_COMPLETED"
    state["updated_at"] = completed_at
    write_data(state_path, state_doc)
    append_jsonl(root / ".harness/events/EVENTS.jsonl", {"type": "TASK_COMPLETED", "task_ref": completed_ref, "run_ref": run["id"], "at": completed_at})
    render_roadmap(root)
    if not next_id:
        write_data(root / ".harness/state/NEXT_TASK.yaml", {"next_task": {"status": "PROJECT_COMPLETED", "task_ref": None, "run_ref": None}})
    render_status(root)
    boundary = record_phase_boundary(
        root,
        active,
        phase="COMPLETED",
        kernel_written_paths=[
            run_path,
            task_report_path,
            f".harness/tasks/{completed_task['id']}@{completed_task['revision']}.yaml",
            ".harness/tasks/INDEX.yaml",
            ".harness/work-packages/INDEX.yaml",
            ".harness/state/CURRENT_STATE.yaml",
            ".harness/state/NEXT_TASK.yaml",
            ".harness/events/EVENTS.jsonl",
            "ROADMAP.md",
            "STATUS.md",
        ],
        recorded_at=completed_at,
    )
    response: dict[str, Any] = {
        "status": "COMPLETED",
        "task_ref": completed_ref,
        "run_ref": run["id"],
        "run_status": "SUCCEEDED",
        "task_status": "DONE",
        "task_report_ref": task_report_id,
        "project_status": state["project_status"],
        "phase_boundary_digest": boundary["boundary_digest"],
    }
    if next_id:
        next_bundle = reserve_run(root, next_id)
        response["next"] = next_bundle
    return response


def block_current(root: Path, reason: str, *, options: list[str] | None = None) -> dict[str, Any]:
    root = root.expanduser().resolve()
    state_path, state_doc = _state(root)
    state = state_doc["state"]
    active = state.get("active_run")
    if not isinstance(active, dict):
        raise ValidationFailure("No active run to block")
    task_id = str(active["task_ref"]).split("@")[0]
    task, _ = _task(root, task_id)
    blocker_id = _next_blocker_id(root, task_id)
    recovery = options or ["Resolve missing input and resume", "Change task scope", "Defer task", "Cancel route"]
    recorded_at = utc_now()
    blocker = {
        "id": blocker_id,
        "revision": 1,
        "kind": "EXECUTION_BLOCKER",
        "task_ref": active["task_ref"],
        "run_ref": active["run_ref"],
        "reason": reason,
        "recovery_options": recovery,
        "resume_condition": "A resolution note is supplied and the affected task contract remains valid or is revised through an approved decision.",
        "status": "OPEN",
        "created_at": recorded_at,
    }
    write_data(root / f".harness/blockers/{blocker_id}@1.yaml", {"blocker": blocker})
    run = {
        "id": active["run_ref"],
        "task_ref": active["task_ref"],
        "attempt_no": active["attempt_no"],
        "run_plan_ref": active["run_plan_ref"],
        "status": "BLOCKED",
        "blocker_ref": blocker_id,
        "evidence_refs": [active.get("verification_evidence_ref")] if active.get("verification_evidence_ref") else [],
        "compensation_status": "NOT_REQUIRED",
        "completed_at": recorded_at,
    }
    run_path = f".harness/runtime/RUNS/{run['id']}.yaml"
    write_data(root / run_path, {"run": run})
    blocked_task = _write_task_revision(root, task_id, status="BLOCKED", blocker_ref=blocker_id, blocked_at=recorded_at)
    blocked_ref = f"{blocked_task['id']}@{blocked_task['revision']}"
    state["active_run"] = None
    state.setdefault("blocked_task_refs", []).append(blocked_ref)
    state.setdefault("open_blocker_refs", []).append(blocker_id)
    state["current_task_ref"] = task_id
    state["project_status"] = "BLOCKED"
    state["next_route"] = "RESOLVE_BLOCKER_OR_CHANGE_SCOPE"
    state["updated_at"] = recorded_at
    write_data(state_path, state_doc)
    _update_wp_status(root, task["work_package_ref"])
    write_data(root / ".harness/state/NEXT_TASK.yaml", {"next_task": {"status": "BLOCKED", "task_ref": blocked_ref, "blocker_ref": blocker_id, "recovery_options": recovery}})
    append_jsonl(root / ".harness/events/EVENTS.jsonl", {"type": "TASK_BLOCKED", "task_ref": active["task_ref"], "run_ref": run["id"], "blocker_ref": blocker_id, "at": recorded_at})
    render_roadmap(root)
    render_status(root)
    record_phase_boundary(
        root,
        active,
        phase="BLOCKED",
        kernel_written_paths=[
            f".harness/blockers/{blocker_id}@1.yaml",
            run_path,
            f".harness/tasks/{blocked_task['id']}@{blocked_task['revision']}.yaml",
            ".harness/tasks/INDEX.yaml",
            ".harness/work-packages/INDEX.yaml",
            ".harness/state/CURRENT_STATE.yaml",
            ".harness/state/NEXT_TASK.yaml",
            ".harness/events/EVENTS.jsonl",
            "ROADMAP.md",
            "STATUS.md",
        ],
        recorded_at=recorded_at,
    )
    return {"status": "BLOCKED", "task_ref": blocked_ref, "run_ref": run["id"], "blocker_ref": blocker_id, "recovery_options": recovery}


def resume_blocked(root: Path, *, resolution: str, blocker_ref: str | None = None) -> dict[str, Any]:
    root = root.expanduser().resolve()
    ensure_current_project_contract(root)
    state_path, state_doc = _state(root)
    state = state_doc["state"]
    blocker_refs = state.get("open_blocker_refs") or []
    blocker_ref = blocker_ref or (blocker_refs[-1] if blocker_refs else None)
    if not blocker_ref:
        raise ValidationFailure("No open blocker to resume")
    blocker_path = root / f".harness/blockers/{blocker_ref}@1.yaml"
    if not blocker_path.exists():
        raise ValidationFailure("Blocker record is missing", blocker_ref)
    blocker = load_data(blocker_path)["blocker"]
    if blocker.get("status") != "OPEN":
        raise ValidationFailure("Blocker is not OPEN", blocker_ref)
    if blocker.get("kind") == "SAFETY_VIOLATION" or state.get("next_route") == SAFETY_RECOVERY_ROUTE:
        raise SafetyViolation(
            "A control-plane safety blocker cannot be resumed in place",
            {"blocker_ref": blocker_ref, "next_route": SAFETY_RECOVERY_ROUTE},
        )
    task_id = str(blocker["task_ref"]).split("@")[0]
    blocker["revision"] = 2
    blocker["previous_revision_ref"] = f"{blocker_ref}@1"
    blocker["status"] = "RESOLVED"
    blocker["resolution"] = resolution
    blocker["resolved_at"] = utc_now()
    write_data(root / f".harness/blockers/{blocker_ref}@2.yaml", {"blocker": blocker})
    ready_task = _write_task_revision(root, task_id, status="READY", blocker_ref=None, resumed_at=utc_now())
    state["blocked_task_refs"] = [ref for ref in state.get("blocked_task_refs") or [] if str(ref).split("@")[0] != task_id]
    state["open_blocker_refs"] = [ref for ref in blocker_refs if ref != blocker_ref]
    state["current_task_ref"] = task_id
    state["project_status"] = "ACTIVE"
    state["next_route"] = "COMPILE_RESUMED_TASK"
    state["updated_at"] = utc_now()
    write_data(state_path, state_doc)
    append_jsonl(root / ".harness/events/EVENTS.jsonl", {"type": "BLOCKER_RESOLVED", "blocker_ref": blocker_ref, "task_ref": f"{ready_task['id']}@{ready_task['revision']}", "at": utc_now()})
    render_roadmap(root)
    render_status(root)
    bundle = reserve_run(root, task_id)
    return {"status": "RESUMED", "blocker_ref": f"{blocker_ref}@2", "task_ref": f"{ready_task['id']}@{ready_task['revision']}", "next": bundle}
