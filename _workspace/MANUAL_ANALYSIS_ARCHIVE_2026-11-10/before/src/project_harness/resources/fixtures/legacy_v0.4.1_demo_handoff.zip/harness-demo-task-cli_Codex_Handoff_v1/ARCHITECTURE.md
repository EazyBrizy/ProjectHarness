# Architecture Baseline

**Статус:** ACCEPTED

## Summary

A single Python module exposes CLI commands and a small JSON-backed repository abstraction.

## Style

MODULAR_MONOLITH_CLI

## Components

- CLI parser
- Task repository

## Interfaces

- Command-line arguments
- Local JSON file

## Data flow

- CLI input -> command handler -> repository -> JSON file -> rendered output

## Quality attributes

- Offline operation
- Deterministic behavior
- Portable standard-library implementation

## Material decisions

- Use a single Python module for the first vertical slice

## Risks

- Concurrent writers are outside the accepted first scope
