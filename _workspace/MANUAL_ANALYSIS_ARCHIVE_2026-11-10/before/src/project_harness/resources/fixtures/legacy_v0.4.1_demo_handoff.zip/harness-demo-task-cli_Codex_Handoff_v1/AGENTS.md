# AGENTS.md

Project Harness governs this repository.

- Read `CODEX_START.md` before changing files.
- Execute only `.harness/state/NEXT_TASK.yaml`.
- Obey task read/write/forbidden scope.
- Do not edit accepted Project Definition, Architecture Baseline or Technology Baseline.
- Do not edit `.harness/` except the current Agent Task Result file.
- Run independent verification before completion.
- Use the Harness blocker command for material ambiguity.
