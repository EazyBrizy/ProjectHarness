# Codex execution bundle — TSK-HARNESS-DEMO-TASK-CLI-001

## Role

Act as the bounded implementation executor for Project Harness. Implement only the current atomic task. Do not redesign accepted baselines, choose another task, or broaden scope silently.

## Current task

- Task: `TSK-HARNESS-DEMO-TASK-CLI-001@1`
- Run reservation: `RUN-HARNESS-DEMO-TASK-CLI-001-A1`
- Title: Implement add and list commands
- Type: `IMPLEMENT`
- Purpose: Create the storage foundation and the first two user commands.
- Expected result: task_cli.py supports add and list, tests pass and README contains usage.
- Dependencies already satisfied: none

## Project outcome

A user needs a tiny local command-line task list without network dependencies.

## Accepted architecture

- Style: MODULAR_MONOLITH_CLI
- Summary: A single Python module exposes CLI commands and a small JSON-backed repository abstraction.

## Accepted technology selections

- LANGUAGE: Python >=3.11
- TEST_FRAMEWORK: unittest stdlib

## Acceptance criteria

- add appends a task with a stable numeric id and incomplete state
- list renders persisted tasks
- tests use an isolated temporary data file
- README documents add and list

## Filesystem scope

### Read

- PROJECT.md
- ARCHITECTURE.md
- TECHNOLOGY.md
- README.md

### Write

- task_cli.py
- tests/**
- README.md

### Forbidden

- CODEX_START.md
- AGENTS.md
- PROJECT.md
- ARCHITECTURE.md
- TECHNOLOGY.md

Never edit `.harness/` or generated Harness root views manually. `PROJECT_CONTROL_WRITE` is prohibited except for the bounded protocol exception that permits one regular JSON file at the exact Agent Task Result path shown below. Symlinks, hardlinks, alternate Run IDs, and any other control-plane write are forbidden.

## Documentation impact

- Impact: `UPDATE_EXISTING`
- Required updates:
- README.md: add and list command examples

## Verification

Commands:
- `python -m py_compile task_cli.py` (cwd `.`)
- `python -m unittest discover -s tests -v` (cwd `.`)

Expected paths:
- task_cli.py
- tests/test_task_cli.py
- README.md

Manual checks:
- none

After implementation run independent Harness verification:

```bash
python .harness/engine/project-harness.py verify --project . --allow-command-execution
```

## Required result contract

Write JSON to `.harness/runtime/AGENT_RESULTS/RUN-HARNESS-DEMO-TASK-CLI-001-A1.json` with this shape:

```json
{
  "schema_version": 1,
  "task_ref": "TSK-HARNESS-DEMO-TASK-CLI-001@1",
  "run_ref": "RUN-HARNESS-DEMO-TASK-CLI-001-A1",
  "status": "COMPLETED",
  "summary": "what was implemented",
  "changes": {"added": [], "modified": [], "deleted": []},
  "commands": [],
  "tests": [],
  "evidence": [],
  "blockers": [],
  "notes": []
}
```

Then complete the transition:

```bash
python .harness/engine/project-harness.py complete --project . --result .harness/runtime/AGENT_RESULTS/RUN-HARNESS-DEMO-TASK-CLI-001-A1.json
```

If a material ambiguity or blocked dependency appears, do not improvise. Use:

```bash
python .harness/engine/project-harness.py block --project . --reason "<precise blocker>" --option "<safe recovery option>"
```
