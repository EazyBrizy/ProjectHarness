from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile
from typing import Any

from .errors import ValidationFailure
from .hashing import parse_manifest, sha256_file, tree_entries
from .planner import topological_order
from .registry import EXPECTED_REGISTRY_VERSIONS, REGISTRY_NAMES, load_registries
from .resources import distribution_root
from .safety import detect_single_root, inspect_zip, safe_extract_zip
from .serialization import load_data
from .util import ENGINE_VERSION, SCHEMA_VERSION
from .workspace import check_control_plane

FORBIDDEN_ACCOUNTING_KEYS = {
    "provider_billing", "provider_cost", "billing_account", "token_ledger",
    "token_usage", "token_count", "input_tokens", "output_tokens", "cost_estimate",
}
LEGACY_ENGINE_VERSION = "0.4.0"
LEGACY_SCHEMA_VERSION = 4
LEGACY_REGISTRY_VERSIONS = {
    **EXPECTED_REGISTRY_VERSIONS,
    "statuses": 3,
    "contracts": 2,
}
LEGACY_MIGRATION_ID = "MIG-ENGINE-0.4.0-TO-0.4.1"
OPERATION_JOURNAL_PREFIX = ".harness/runtime/OPERATION_JOURNAL/"


def _check(name: str, ok: bool, details: Any) -> dict[str, Any]:
    return {"name": name, "status": "PASS" if ok else "FAIL", "details": details}


def _walk(value: Any, path: str = ""):
    yield path, value
    if isinstance(value, dict):
        for key, child in value.items():
            next_path = f"{path}.{key}" if path else str(key)
            yield from _walk(child, next_path)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from _walk(child, f"{path}[{index}]")


def _manifest_check(root: Path) -> tuple[bool, dict[str, Any]]:
    path = root / "MANIFEST.sha256"
    if not path.exists():
        return False, {"missing": "MANIFEST.sha256"}
    expected = parse_manifest(path)
    actual_paths: dict[str, Path] = {}
    for candidate in tree_entries(
        root,
        exclude_dirs={"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"},
        exclude_files={"MANIFEST.sha256"},
    ):
        rel = candidate.relative_to(root).as_posix()
        if candidate.suffix.lower() in {".pyc", ".pyo"} or rel.startswith(OPERATION_JOURNAL_PREFIX):
            continue
        actual_paths[rel] = candidate
    missing = sorted(set(expected) - set(actual_paths))
    extra = sorted(set(actual_paths) - set(expected))
    mismatched = sorted(
        rel for rel in set(expected) & set(actual_paths)
        if sha256_file(actual_paths[rel]) != expected[rel]
    )
    return not missing and not extra and not mismatched, {
        "entries": len(expected),
        "missing": missing,
        "extra": extra,
        "mismatched": mismatched,
        "excluded_runtime_records": [OPERATION_JOURNAL_PREFIX + "*"],
    }


def _resource_copy_check(root: Path) -> tuple[bool, dict[str, Any]]:
    embedded = root / "src/project_harness/resources"
    if not embedded.is_dir():
        return True, {"layout": "installed", "checked": 0, "errors": []}
    errors: list[str] = []
    checked = 0
    for folder in ("registries", "schemas", "templates", "fixtures", "skills"):
        source_dir = root / folder
        embedded_dir = embedded / folder
        source_files = {
            path.relative_to(source_dir).as_posix(): path
            for path in source_dir.rglob("*") if path.is_file() and path.suffix.lower() not in {".pyc", ".pyo"}
        }
        embedded_files = {
            path.relative_to(embedded_dir).as_posix(): path
            for path in embedded_dir.rglob("*") if path.is_file() and path.suffix.lower() not in {".pyc", ".pyo"}
        } if embedded_dir.is_dir() else {}
        for rel in sorted(set(source_files) | set(embedded_files)):
            checked += 1
            if rel not in source_files:
                errors.append(f"{folder}/{rel}: embedded-only")
            elif rel not in embedded_files:
                errors.append(f"{folder}/{rel}: source-only")
            elif sha256_file(source_files[rel]) != sha256_file(embedded_files[rel]):
                errors.append(f"{folder}/{rel}: digest mismatch")
    version_source = root / "VERSION"
    version_embedded = embedded / "VERSION"
    if version_source.exists() and version_embedded.exists():
        checked += 1
        if sha256_file(version_source) != sha256_file(version_embedded):
            errors.append("VERSION: source/embedded digest mismatch")
    return not errors, {"layout": "source", "checked": checked, "errors": errors}


def doctor(root: Path | None = None, *, check_manifest: bool = True) -> dict[str, Any]:
    root = (root or distribution_root()).resolve()
    checks: list[dict[str, Any]] = []
    try:
        registries = load_registries(root)
        checks.append(_check("Canonical registries", True, {name: registries[name]["registry"]["version"] for name in REGISTRY_NAMES}))
    except Exception as exc:
        checks.append(_check("Canonical registries", False, str(exc)))
    schema_errors: list[str] = []
    schema_count = 0
    for path in sorted((root / "schemas").glob("*.json")):
        schema_count += 1
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(value, dict) or value.get("$schema") != "https://json-schema.org/draft/2020-12/schema":
                schema_errors.append(f"{path.name}: missing Draft 2020-12 declaration")
        except Exception as exc:
            schema_errors.append(f"{path.name}: {exc}")
    checks.append(_check("Bundled schemas", not schema_errors and schema_count >= 3, {"count": schema_count, "errors": schema_errors}))
    skill_errors: list[str] = []
    skills = list((root / "skills").glob("SKL-*.yaml"))
    for path in skills:
        try:
            skill = load_data(path)["skill"]
            if skill.get("status") != "ACTIVE":
                skill_errors.append(f"{path.name}: status={skill.get('status')}")
        except Exception as exc:
            skill_errors.append(f"{path.name}: {exc}")
    checks.append(_check("Seed ACTIVE skills", not skill_errors and bool(skills), {"count": len(skills), "errors": skill_errors}))
    if (root / "src/project_harness/cli.py").exists():
        required = ["project-harness.py", "src/project_harness/cli.py", "templates/GPT_PREPARATION_INSTRUCTIONS.md"]
    else:
        required = ["templates/GPT_PREPARATION_INSTRUCTIONS.md", "fixtures/demo_project_input.json"]
    missing = [item for item in required if not (root / item).exists()]
    checks.append(_check("Entry points and browser preparation template", not missing, {"missing": missing, "layout": "source" if (root / "src").exists() else "installed"}))
    resources_ok, resource_details = _resource_copy_check(root)
    checks.append(_check("Source and embedded resources", resources_ok, resource_details))
    if check_manifest and (root / "MANIFEST.sha256").exists():
        ok, details = _manifest_check(root)
        checks.append(_check("Distribution manifest", ok, details))
    status = "PASS" if all(item["status"] == "PASS" for item in checks) else "FAIL"
    return {"version": ENGINE_VERSION, "schema_version": SCHEMA_VERSION, "status": status, "root": str(root), "checks": checks}


def _load_handoff_registries(root: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    statuses = load_data(root / ".harness/registries/statuses.yaml")
    contracts = load_data(root / ".harness/registries/contracts.yaml")
    status_registry = statuses.get("registry") if isinstance(statuses, dict) else None
    contract_registry = contracts.get("registry") if isinstance(contracts, dict) else None
    if not isinstance(status_registry, dict) or not isinstance(contract_registry, dict):
        raise ValidationFailure("Handoff status/contracts registry envelope is invalid")
    return status_registry, contract_registry


def _status_allowed(groups: dict[str, Any], group: str, status: Any) -> bool:
    return isinstance(status, str) and status in set(groups.get(group) or [])


def _legacy_status_allowed(
    *,
    entity: str,
    status: Any,
    rel: str,
    compatibility_mode: bool,
    migrated_legacy: bool,
    current_task_paths: set[str],
    completed_at: Any,
    lock_created_at: Any,
) -> tuple[bool, str | None]:
    if status != "COMPLETED" or entity not in {"task", "run"}:
        return False, None
    target = "DONE" if entity == "task" else "SUCCEEDED"
    if compatibility_mode:
        return True, target
    if not migrated_legacy:
        return False, None
    # A migrated v0.4.1 handoff may retain immutable pre-migration history, but
    # a current Task revision or a newly completed Run never receives the map.
    if entity == "task" and rel not in current_task_paths:
        if completed_at and lock_created_at and str(completed_at) <= str(lock_created_at):
            return True, target
    if entity == "run" and completed_at and lock_created_at and str(completed_at) <= str(lock_created_at):
        return True, target
    return False, None


def _validate_entity_statuses(
    root: Path,
    *,
    groups: dict[str, Any],
    compatibility_mode: bool,
    migrated_legacy: bool,
    lock_created_at: Any,
) -> tuple[list[str], list[dict[str, Any]]]:
    errors: list[str] = []
    mappings: list[dict[str, Any]] = []
    task_index_path = root / ".harness/tasks/INDEX.yaml"
    current_task_paths: set[str] = set()
    if task_index_path.exists():
        try:
            current_task_paths = set(load_data(task_index_path)["task_index"].get("current", {}).values())
        except Exception:
            pass

    specs = [
        (root / ".harness/tasks", "TSK-*@*.yaml", "task", "task"),
        (root / ".harness/runtime/RUNS", "RUN-*.yaml", "run", "run"),
        (root / ".harness/work-packages", "WP-*@*.yaml", "work_package", "work_package"),
        (root / ".harness/canonical/DECISIONS", "DEC-*@*.yaml", "decision", "decision"),
    ]
    for base, pattern, envelope, group in specs:
        if not base.exists():
            continue
        for path in sorted(base.glob(pattern)):
            rel = path.relative_to(root).as_posix()
            try:
                value = load_data(path)
                entity = value.get(envelope) if isinstance(value, dict) else None
                if not isinstance(entity, dict):
                    errors.append(f"{rel}: missing {envelope} envelope")
                    continue
                status = entity.get("status")
                if _status_allowed(groups, group, status):
                    continue
                if compatibility_mode and envelope == "decision" and status in {"ACCEPTED", "REJECTED", "SUPERSEDED"}:
                    # v0.4.0 persisted Decision records before registering their
                    # lifecycle group in statuses.yaml.
                    continue
                allowed, interpreted = _legacy_status_allowed(
                    entity=envelope,
                    status=status,
                    rel=rel,
                    compatibility_mode=compatibility_mode,
                    migrated_legacy=migrated_legacy,
                    current_task_paths=current_task_paths,
                    completed_at=entity.get("completed_at"),
                    lock_created_at=lock_created_at,
                )
                if allowed:
                    mappings.append({
                        "path": rel,
                        "entity": envelope,
                        "id": entity.get("id"),
                        "legacy_status": "COMPLETED",
                        "interpreted_as": interpreted,
                        "file_rewritten": False,
                    })
                else:
                    errors.append(f"{rel}: {envelope}.status={status!r} is not in registry.{group}")
            except Exception as exc:
                errors.append(f"{rel}: {exc}")

    result_schema_path = root / ".harness/engine/project_harness/resources/schemas/agent_task_result.schema.json"
    result_statuses = {"COMPLETED", "BLOCKED", "FAILED"}
    if result_schema_path.exists():
        try:
            schema = json.loads(result_schema_path.read_text(encoding="utf-8"))
            result_statuses = set(schema["properties"]["status"]["enum"])
        except Exception as exc:
            errors.append(f"{result_schema_path.relative_to(root)}: cannot read Agent Result enum: {exc}")
    results_dir = root / ".harness/runtime/AGENT_RESULTS"
    if results_dir.exists():
        for path in sorted(results_dir.glob("*.json")):
            rel = path.relative_to(root).as_posix()
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
                if value.get("status") not in result_statuses:
                    errors.append(f"{rel}: Agent Result status={value.get('status')!r} is invalid")
            except Exception as exc:
                errors.append(f"{rel}: {exc}")
    return errors, mappings


def _validate_decisions_and_brownfield(
    root: Path,
    *,
    project: dict[str, Any],
    status_groups: dict[str, Any],
    contract_registry: dict[str, Any],
    compatibility_mode: bool,
    migrated_legacy: bool,
) -> tuple[bool, dict[str, Any]]:
    errors: list[str] = []
    decision_contract = (contract_registry.get("entities") or {}).get("decision")
    expected_contract = {
        "id_prefix": "DEC",
        "persistence": "PERSISTENT",
        "lifecycle": "decision",
        "storage_path": ".harness/canonical/DECISIONS/{id}@{revision}.yaml",
        "revision_policy": "IMMUTABLE",
    }
    legacy_contract_gap = False
    if not isinstance(decision_contract, dict):
        if compatibility_mode:
            legacy_contract_gap = True
        else:
            errors.append("decision contract is not registered")
    else:
        for key, expected in expected_contract.items():
            if decision_contract.get(key) != expected:
                errors.append(f"decision contract {key}={decision_contract.get(key)!r}, expected {expected!r}")

    decisions: dict[str, dict[str, Any]] = {}
    for path in sorted((root / ".harness/canonical/DECISIONS").glob("DEC-*@*.yaml")):
        rel = path.relative_to(root).as_posix()
        try:
            value = load_data(path).get("decision")
            if not isinstance(value, dict):
                errors.append(f"{rel}: missing decision envelope")
                continue
            expected_name = f"{value.get('id')}@{value.get('revision')}.yaml"
            if path.name != expected_name:
                errors.append(f"{rel}: storage path does not match immutable decision id/revision")
            decision_status = value.get("status")
            if not _status_allowed(status_groups, "decision", decision_status):
                if not (compatibility_mode and decision_status in {"ACCEPTED", "REJECTED", "SUPERSEDED"}):
                    errors.append(f"{rel}: invalid decision status {decision_status!r}")
            decisions[str(value.get("id"))] = value
        except Exception as exc:
            errors.append(f"{rel}: {exc}")

    mode = project.get("lifecycle_mode")
    baselines = list((root / ".harness/canonical/DEFINITION/BROWNFIELD").glob("BFB-*@*.yaml"))
    legacy_brownfield_approval_gap = False
    legacy_brownfield_revisions: list[str] = []
    if mode in {"BROWNFIELD", "HYBRID"}:
        if not baselines:
            errors.append("Brownfield/Hybrid project has no accepted Brownfield Baseline")
        parsed_baselines: list[tuple[Path, dict[str, Any]]] = []
        for path in baselines:
            try:
                bfb = load_data(path).get("brownfield_baseline")
                if isinstance(bfb, dict):
                    parsed_baselines.append((path, bfb))
            except Exception:
                pass
        latest_revision_by_id: dict[str, int] = {}
        for _path, bfb in parsed_baselines:
            baseline_id = str(bfb.get("id"))
            latest_revision_by_id[baseline_id] = max(latest_revision_by_id.get(baseline_id, 0), int(bfb.get("revision", 0)))
        for path in baselines:
            rel = path.relative_to(root).as_posix()
            try:
                bfb = load_data(path).get("brownfield_baseline")
                if not isinstance(bfb, dict):
                    errors.append(f"{rel}: invalid Brownfield Baseline envelope")
                    continue
                decision_id = bfb.get("accepted_by")
                accepted_at = bfb.get("accepted_at")
                if compatibility_mode and (not decision_id or not accepted_at):
                    legacy_brownfield_approval_gap = True
                    continue
                is_historical_migrated = (
                    migrated_legacy
                    and int(bfb.get("revision", 0)) < latest_revision_by_id.get(str(bfb.get("id")), 0)
                )
                if is_historical_migrated and (not decision_id or not accepted_at):
                    legacy_brownfield_revisions.append(rel)
                    continue
                decision = decisions.get(str(decision_id))
                if not decision:
                    errors.append(f"{rel}: accepted_by does not resolve to an immutable Decision")
                    continue
                if decision.get("kind") != "BROWNFIELD_BASELINE_APPROVAL":
                    errors.append(f"{rel}: accepted_by Decision has wrong kind")
                if decision.get("subject_ref") != f"{bfb.get('id')}@{bfb.get('revision')}":
                    errors.append(f"{rel}: Decision subject_ref does not reference this baseline")
                if decision.get("approved_at") != accepted_at:
                    errors.append(f"{rel}: accepted_at differs from Decision approved_at")
                if not decision.get("actor"):
                    errors.append(f"{rel}: Decision actor is missing")
            except Exception as exc:
                errors.append(f"{rel}: {exc}")
    elif baselines:
        errors.append("Greenfield project unexpectedly contains a Brownfield Baseline")
    return not errors, {
        "decisions": len(decisions),
        "brownfield_baselines": len(baselines),
        "legacy_contract_gap": legacy_contract_gap,
        "legacy_brownfield_approval_gap": legacy_brownfield_approval_gap,
        "legacy_brownfield_revisions": legacy_brownfield_revisions,
        "errors": errors,
    }


def validate_handoff_directory(
    root: Path,
    *,
    check_manifest: bool = True,
    check_control_plane_state: bool = True,
) -> dict[str, Any]:
    root = root.resolve()
    checks: list[dict[str, Any]] = []
    legacy_status_mappings: list[dict[str, Any]] = []
    required = [
        "CODEX_START.md", "AGENTS.md", "HANDOFF_SUMMARY.md", "PROJECT.md", "ARCHITECTURE.md", "TECHNOLOGY.md", "ROADMAP.md", "STATUS.md",
        ".harness/config/PROJECT.yaml", ".harness/config/PROJECT_LOCK.yaml",
        ".harness/state/CURRENT_STATE.yaml", ".harness/state/NEXT_TASK.yaml",
        ".harness/tasks/INDEX.yaml", ".harness/work-packages/INDEX.yaml",
        ".harness/skills/registry.yaml", ".harness/engine/project-harness.py",
    ]
    missing = [item for item in required if not (root / item).exists()]
    checks.append(_check("Required handoff artifacts", not missing, {"missing": missing}))

    symlinks = [p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_symlink()]
    checks.append(_check("No symlinks", not symlinks, {"symlinks": symlinks}))

    parse_errors: list[str] = []
    parsed_values: list[tuple[str, Any]] = []
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root).as_posix()
        if rel.startswith(OPERATION_JOURNAL_PREFIX):
            # Journal integrity is checked by the control-plane protocol below.
            continue
        if path.is_file() and path.suffix.lower() in {".yaml", ".yml", ".json"}:
            try:
                value = load_data(path)
                parsed_values.append((rel, value))
            except Exception as exc:
                parse_errors.append(f"{rel}: {exc}")
    checks.append(_check("Machine-readable files parse", not parse_errors, {"parsed": len(parsed_values), "errors": parse_errors[:20]}))

    compatibility_mode = False
    migrated_legacy = False
    if not missing:
        project = load_data(root / ".harness/config/PROJECT.yaml")["project"]
        lock = load_data(root / ".harness/config/PROJECT_LOCK.yaml")["project_lock"]
        engine = lock.get("harness_distribution")
        schema = lock.get("schema_version")
        compatibility_mode = engine == LEGACY_ENGINE_VERSION and schema == LEGACY_SCHEMA_VERSION
        current_mode = engine == ENGINE_VERSION and schema == SCHEMA_VERSION
        migrated_legacy = (
            LEGACY_MIGRATION_ID in set(lock.get("migrations_applied") or [])
            and lock.get("migrated_from") == LEGACY_ENGINE_VERSION
        )
        legacy_cutoff = lock.get("migrated_at") if migrated_legacy else lock.get("created_at")
        checks.append(_check(
            "Engine/schema lock",
            current_mode or compatibility_mode,
            {
                "engine": engine,
                "schema": schema,
                "mode": "LEGACY_V0.4.0_COMPATIBILITY" if compatibility_mode else ("CURRENT" if current_mode else "UNSUPPORTED"),
                "expected_current": {"engine": ENGINE_VERSION, "schema": SCHEMA_VERSION},
            },
        ))

        version_errors: list[str] = []
        digest_errors: list[str] = []
        expected_versions = LEGACY_REGISTRY_VERSIONS if compatibility_mode else EXPECTED_REGISTRY_VERSIONS
        for name in REGISTRY_NAMES:
            expected_version = expected_versions[name]
            actual_version = (lock.get("registry_versions") or {}).get(name)
            if actual_version != expected_version:
                version_errors.append(f"{name}: {actual_version} != {expected_version}")
            path = root / ".harness/registries" / f"{name}.yaml"
            try:
                file_version = load_data(path)["registry"].get("version") if path.exists() else None
            except Exception:
                file_version = None
            if file_version != actual_version:
                version_errors.append(f"{name}: registry file version {file_version} != lock {actual_version}")
            expected_digest = (lock.get("registry_digests") or {}).get(name)
            actual_digest = f"sha256:{sha256_file(path)}" if path.exists() else None
            if expected_digest != actual_digest:
                digest_errors.append(f"{name}: digest mismatch")
        checks.append(_check("Exact registry versions", not version_errors, {"errors": version_errors, "compatibility_mode": compatibility_mode}))
        checks.append(_check("Exact registry digests", not digest_errors, {"errors": digest_errors}))

        try:
            status_registry, contract_registry = _load_handoff_registries(root)
            groups = status_registry.get("groups") or {}
            status_errors, legacy_status_mappings = _validate_entity_statuses(
                root,
                groups=groups,
                compatibility_mode=compatibility_mode,
                migrated_legacy=migrated_legacy,
                lock_created_at=legacy_cutoff,
            )
            checks.append(_check("Registry-driven entity statuses", not status_errors, {"errors": status_errors, "legacy_status_mappings": legacy_status_mappings}))
            decision_ok, decision_details = _validate_decisions_and_brownfield(
                root,
                project=project,
                status_groups=groups,
                contract_registry=contract_registry,
                compatibility_mode=compatibility_mode,
                migrated_legacy=migrated_legacy,
            )
            checks.append(_check("Decision contract and Brownfield approval", decision_ok, decision_details))
        except Exception as exc:
            checks.append(_check("Registry-driven entity statuses", False, {"errors": [str(exc)], "legacy_status_mappings": []}))
            checks.append(_check("Decision contract and Brownfield approval", False, {"errors": [str(exc)]}))

        task_index = load_data(root / ".harness/tasks/INDEX.yaml")["task_index"]
        tasks: list[dict[str, Any]] = []
        task_errors: list[str] = []
        for task_id in task_index.get("order") or []:
            rel = (task_index.get("current") or {}).get(task_id)
            if not rel or not (root / rel).exists():
                task_errors.append(f"{task_id}: missing current path")
                continue
            task = load_data(root / rel).get("task")
            if not isinstance(task, dict) or task.get("id") != task_id:
                task_errors.append(f"{task_id}: invalid entity")
                continue
            tasks.append(task)
        try:
            computed_order = topological_order(tasks)
        except Exception as exc:
            computed_order = []
            task_errors.append(str(exc))
        if computed_order and computed_order != task_index.get("order"):
            task_errors.append(f"task order mismatch: {computed_order}")
        checks.append(_check("Task index and causal DAG", not task_errors and bool(tasks), {"tasks": len(tasks), "errors": task_errors}))

        state = load_data(root / ".harness/state/CURRENT_STATE.yaml")["state"]
        active = state.get("active_run") or {}
        current = state.get("current_task_ref")
        project_status = state.get("project_status")
        active_errors: list[str] = []
        if current and current not in (task_index.get("current") or {}):
            active_errors.append("current task absent from index")
        if active:
            required_active_fields = ["run_ref", "task_ref", "prompt_bundle_path", "prompt_markdown_path", "snapshot_path"]
            if not compatibility_mode:
                required_active_fields.extend(["allowed_agent_output_path", "operation_journal_path", "control_plane_phase"])
            for field in required_active_fields:
                if not active.get(field):
                    active_errors.append(f"active_run.{field} missing")
            path_fields = ["prompt_bundle_path", "prompt_markdown_path", "snapshot_path"]
            if not compatibility_mode:
                path_fields.append("operation_journal_path")
            for field in path_fields:
                if active.get(field) and not (root / active[field]).exists():
                    active_errors.append(f"missing {active[field]}")
            if not compatibility_mode:
                expected_result = f".harness/runtime/AGENT_RESULTS/{active.get('run_ref')}.json"
                if active.get("allowed_agent_output_path") != expected_result:
                    active_errors.append("active_run.allowed_agent_output_path is not the exact Run channel")
        if project_status == "COMPLETED":
            if current is not None:
                active_errors.append("completed project must not have current_task_ref")
            if active:
                active_errors.append("completed project must not have active_run")
        elif project_status == "BLOCKED" or (state.get("open_blocker_refs") and not active):
            if not current:
                active_errors.append("blocked project must retain current_task_ref")
            if active:
                active_errors.append("blocked project must not retain active_run")
            if not state.get("open_blocker_refs"):
                active_errors.append("blocked project requires an OPEN blocker")
        else:
            if not active:
                active_errors.append("active project requires active_run")
        checks.append(_check("Current task and runtime state", not active_errors, {"project_status": project_status, "current_task": current, "run": active.get("run_ref"), "errors": active_errors}))

        if check_control_plane_state and active and not compatibility_mode:
            invariant = check_control_plane(root, active, allow_missing_agent_result=True)
            checks.append(_check("Protected control-plane phase boundary", invariant.get("status") == "PASS", invariant))

        bundles = list((root / ".harness/prompts/BUNDLES_BY_RUN").glob("CPB-*.yaml"))
        bundle_refs = []
        bundle_errors: list[str] = []
        for path in bundles:
            bundle = load_data(path).get("compiled_prompt_bundle")
            if not isinstance(bundle, dict):
                bundle_errors.append(path.name)
                continue
            bundle_refs.append(bundle.get("id"))
            task_id = str(bundle.get("task_ref", "")).split("@")[0]
            if task_id not in (task_index.get("current") or {}):
                bundle_errors.append(f"{path.name}: unknown task")
        initial_result = root / ".harness/state/HANDOFF_RESULT.json"
        if initial_result.exists():
            handoff = load_data(initial_result)
            if handoff.get("future_compiled_prompt_count") == 0 and len(bundles) != 1 and not state.get("completed_task_refs"):
                bundle_errors.append(f"initial handoff must contain exactly one compiled bundle, found {len(bundles)}")
        checks.append(_check("JIT prompt bundles", not bundle_errors and bool(bundles), {"count": len(bundles), "refs": bundle_refs, "errors": bundle_errors}))

        skill_index = load_data(root / ".harness/skills/registry.yaml").get("skill_registry_index")
        skill_errors: list[str] = []
        if not isinstance(skill_index, dict) or skill_index.get("generated") is not True:
            skill_errors.append("registry is not marked generated")
        else:
            available = {item.get("ref"): item for item in skill_index.get("available") or []}
            for ref in lock.get("skill_refs") or []:
                item = available.get(ref)
                if not item or item.get("status") != "ACTIVE":
                    skill_errors.append(f"locked skill is not ACTIVE: {ref}")
        checks.append(_check("Project skill resolution index", not skill_errors, {"errors": skill_errors}))

        mode = project.get("lifecycle_mode")
        if mode in {"BROWNFIELD", "HYBRID"}:
            portfolio_path = root / ".harness/work-packages/ROUTE_PORTFOLIO/INDEX.yaml"
            routes: list[str] = []
            if portfolio_path.exists():
                refs = load_data(portfolio_path)["brownfield_route_portfolio"].get("route_refs") or []
                for ref in refs:
                    path = root / f".harness/work-packages/ROUTE_PORTFOLIO/{str(ref).split('@')[0]}@1.yaml"
                    if path.exists():
                        routes.append(load_data(path)["brownfield_route_item"]["route"])
            expected_routes = {"CONTINUE_DEVELOPMENT", "FIX_KNOWN_BUGS", "IMPROVE_PROJECT", "STABILIZE_BASELINE"}
            checks.append(_check("Brownfield route portfolio", set(routes) == expected_routes, {"routes": routes}))

    forbidden_hits: list[str] = []
    for rel, value in parsed_values:
        for path, _child in _walk(value):
            leaf = path.replace("]", "").split(".")[-1].split("[")[0]
            if leaf in FORBIDDEN_ACCOUNTING_KEYS:
                forbidden_hits.append(f"{rel}:{path}")
    checks.append(_check("Provider accounting remains excluded", not forbidden_hits, {"hits": forbidden_hits}))

    if check_manifest:
        ok, details = _manifest_check(root)
        checks.append(_check("Handoff manifest", ok, details))

    status = "PASS" if all(item["status"] == "PASS" for item in checks) else "FAIL"
    return {
        "status": status,
        "root": str(root),
        "compatibility_mode": "V0.4.0" if compatibility_mode else None,
        "legacy_status_mappings": legacy_status_mappings,
        "checks": checks,
        "errors": [item for item in checks if item["status"] == "FAIL"],
    }


def validate_handoff(path: Path) -> dict[str, Any]:
    path = path.expanduser().resolve()
    if path.is_dir():
        return validate_handoff_directory(path, check_manifest=True, check_control_plane_state=True)
    if path.suffix.lower() != ".zip":
        raise ValidationFailure("Handoff must be a directory or ZIP archive", str(path))
    inspect_zip(path)
    with tempfile.TemporaryDirectory(prefix="project-harness-validate-") as temp_name:
        destination = Path(temp_name)
        safe_extract_zip(path, destination)
        root = detect_single_root(destination)
        result = validate_handoff_directory(root, check_manifest=True, check_control_plane_state=True)
        result["archive"] = str(path)
        result["archive_sha256"] = f"sha256:{sha256_file(path)}"
        return result


def validate_project_directory(root: Path) -> dict[str, Any]:
    """Validate mutable post-handoff state without enforcing the baseline manifest."""
    return validate_handoff_directory(
        root.expanduser().resolve(),
        check_manifest=False,
        check_control_plane_state=True,
    )
