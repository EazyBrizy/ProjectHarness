from __future__ import annotations

from pathlib import Path
from typing import Any

from .errors import ValidationFailure
from .hashing import sha256_file
from .resources import distribution_root
from .serialization import load_data

REGISTRY_NAMES = (
    "id_prefixes",
    "project_profiles",
    "statuses",
    "request_routing",
    "capabilities",
    "contracts",
)
EXPECTED_REGISTRY_VERSIONS = {
    "id_prefixes": 1,
    "project_profiles": 1,
    "statuses": 4,
    "request_routing": 2,
    "capabilities": 1,
    "contracts": 3,
}


def load_registries(root: Path | None = None) -> dict[str, dict[str, Any]]:
    base = (root or distribution_root()) / "registries"
    values: dict[str, dict[str, Any]] = {}
    errors: list[str] = []
    for name in REGISTRY_NAMES:
        path = base / f"{name}.yaml"
        if not path.exists():
            errors.append(f"missing {path}")
            continue
        value = load_data(path)
        if not isinstance(value, dict) or not isinstance(value.get("registry"), dict):
            errors.append(f"invalid registry envelope: {path}")
            continue
        actual = value["registry"].get("version")
        expected = EXPECTED_REGISTRY_VERSIONS[name]
        if actual != expected:
            errors.append(f"{name}: expected version {expected}, got {actual}")
        values[name] = value
    embedded = (root or distribution_root()) / "src/project_harness/resources/registries"
    if embedded.is_dir():
        for name in REGISTRY_NAMES:
            source_path = base / f"{name}.yaml"
            embedded_path = embedded / f"{name}.yaml"
            if not embedded_path.exists():
                errors.append(f"missing embedded registry copy: {embedded_path}")
            elif source_path.exists() and sha256_file(source_path) != sha256_file(embedded_path):
                errors.append(f"{name}: source/embedded registry digest mismatch")
    if errors:
        raise ValidationFailure("Registry validation failed", errors)
    return values


def registry_lock(root: Path | None = None) -> tuple[dict[str, int], dict[str, str]]:
    base = (root or distribution_root()) / "registries"
    load_registries(root)
    versions = dict(EXPECTED_REGISTRY_VERSIONS)
    digests = {
        name: f"sha256:{sha256_file(base / f'{name}.yaml')}"
        for name in REGISTRY_NAMES
    }
    return versions, digests


def allowed_capabilities(registries: dict[str, dict[str, Any]]) -> set[str]:
    entries = registries["capabilities"]["registry"].get("entries") or []
    return {str(entry["key"]) for entry in entries}


def known_profiles(registries: dict[str, dict[str, Any]]) -> set[str]:
    entries = registries["project_profiles"]["registry"].get("entries") or []
    refs = set()
    for entry in entries:
        ref = entry.get("id") or entry.get("ref")
        if not ref and entry.get("key"):
            ref = "PRF-" + str(entry["key"]).replace("_", "-")
        version = entry.get("version", 1)
        if ref:
            refs.add(f"{ref}@{version}")
    return refs
