from pathlib import Path
import tempfile
import unittest
from task_cli import add_task, complete_task, list_tasks


class TaskCliTests(unittest.TestCase):
    def test_add_and_list(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "tasks.json"
            first = add_task(path, "One")
            second = add_task(path, "Two")
            self.assertEqual((first["id"], second["id"]), (1, 2))
            self.assertEqual([item["title"] for item in list_tasks(path)], ["One", "Two"])
            self.assertFalse(first["done"])

    def test_complete_and_unknown_id(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "tasks.json"
            task = add_task(path, "Finish")
            self.assertTrue(complete_task(path, task["id"])["done"])
            self.assertTrue(list_tasks(path)[0]["done"])
            with self.assertRaisesRegex(ValueError, "Unknown task id"):
                complete_task(path, 999)
