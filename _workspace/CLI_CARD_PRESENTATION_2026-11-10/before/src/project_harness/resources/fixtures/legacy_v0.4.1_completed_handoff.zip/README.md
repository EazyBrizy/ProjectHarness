# Harness Demo Task CLI

The user can add, list and complete tasks stored in a local JSON file.

Implementation is governed by `CODEX_START.md`.

## Usage

`python task_cli.py add \"Example\"` and `python task_cli.py list`.

`python task_cli.py done 1` marks a task complete.
