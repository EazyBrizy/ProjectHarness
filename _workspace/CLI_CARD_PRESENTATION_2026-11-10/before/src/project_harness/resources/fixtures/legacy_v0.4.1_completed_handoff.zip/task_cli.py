from __future__ import annotations
import argparse
import json
from pathlib import Path
from typing import Any


def load_tasks(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    return json.loads(path.read_text(encoding="utf-8"))


def save_tasks(path: Path, tasks: list[dict[str, Any]]) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(tasks, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temp.replace(path)


def add_task(path: Path, title: str) -> dict[str, Any]:
    tasks = load_tasks(path)
    task = {"id": max((item["id"] for item in tasks), default=0) + 1, "title": title, "done": False}
    tasks.append(task)
    save_tasks(path, tasks)
    return task


def list_tasks(path: Path) -> list[dict[str, Any]]:
    return load_tasks(path)


def complete_task(path: Path, task_id: int) -> dict[str, Any]:
    tasks = load_tasks(path)
    for task in tasks:
        if task["id"] == task_id:
            task["done"] = True
            save_tasks(path, tasks)
            return task
    raise ValueError(f"Unknown task id: {task_id}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path("tasks.json"))
    sub = parser.add_subparsers(dest="command", required=True)
    add = sub.add_parser("add")
    add.add_argument("title")
    sub.add_parser("list")
    done = sub.add_parser("done")
    done.add_argument("task_id", type=int)
    args = parser.parse_args()
    if args.command == "add":
        task = add_task(args.data, args.title)
        print(f"Added {task['id']}: {task['title']}")
    elif args.command == "done":
        task = complete_task(args.data, args.task_id)
        print(f"Completed {task['id']}: {task['title']}")
    else:
        for task in list_tasks(args.data):
            marker = "x" if task.get("done") else " "
            print(f"[{marker}] {task['id']}: {task['title']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
